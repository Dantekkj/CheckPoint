# TaskHub

Sistema de gestão para trabalhadores autônomos e equipes.

## Funcionalidades
- Dashboard com métricas em tempo real (WebSocket).
- Gestão de Tarefas (CRUD, filtros, controle de horas).
- Desempenho da Equipe (Ranking, Score semanal, Gráficos).
- Financeiro (Receitas, Despesas, Pagamentos via "Pix" com recibos simulados).
- Clientes e Projetos.

## Stack
- **Back-end:** Node.js, Express, SQLite (via `better-sqlite3`), JWT, WebSocket (`ws`).
- **Front-end:** HTML, Tailwind CSS (via CDN), JavaScript Vanilla, Chart.js.

## Como rodar o projeto

1. Certifique-se de ter o **Node.js** instalado (versão 18+ recomendada).

2. Acesse a pasta do backend e instale as dependências:
   ```bash
   cd backend
   npm install
   ```

3. Popule o banco de dados inicial (com dados de demonstração):
   ```bash
   npm run seed
   ```

4. Inicie o servidor:
   ```bash
   npm start
   ```
   A API rodará na porta `3000`.

5. Em outro terminal, abra a pasta frontend e inicie um servidor estático simples.
   Se não tiver nenhum servidor estático, você pode usar o `npx`:
   ```bash
   cd ../frontend
   npx serve .
   ```
   Ou simplesmente abra o arquivo `frontend/login.html` no seu navegador (embora um servidor web seja recomendado para evitar problemas de CORS em chamadas locais).

## Acesso Demonstração
Os dados padrão do seed já incluem as seguintes contas (a senha para todas é `taskhub123`):

- **Líder:** `rafael@taskhub.dev`
- **Membro:** `ana@taskhub.dev`
- **Membro:** `bruno@taskhub.dev`

Aproveite o TaskHub!
