@echo off
title CheckPoint - Iniciando...

echo.
echo  ======================================
echo         CheckPoint - Inicializando     
echo  ======================================
echo.

:: Forca o Node.js no PATH caso tenha sido recem-instalado
set "PATH=%PATH%;C:\Program Files\nodejs;C:\Program Files (x86)\nodejs"

:: Detecta o Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo  [ERRO] Node.js nao encontrado no PATH.
    echo.
    echo  Por favor instale o Node.js em: https://nodejs.org
    echo  Apos instalar, feche e reabra este arquivo.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set NODE_VER=%%v
echo  Node.js encontrado: %NODE_VER%
echo.

:: Backend
echo  [1/2] Iniciando Backend (porta 3000)...
cd /d "%~dp0backend"

if not exist "node_modules" (
    echo  Instalando dependencias do backend...
    call npm install
    if errorlevel 1 (
        echo  [ERRO] Falha ao instalar dependencias.
        pause
        exit /b 1
    )
)

:: Inicia o backend em nova janela
start "CheckPoint Backend" cmd /c "node src/app.js & pause"

:: Aguarda o backend subir
ping 127.0.0.1 -n 4 > nul

:: Frontend
echo  [2/2] Iniciando Frontend (porta 8080)...
cd /d "%~dp0frontend"

:: Inicia o frontend em nova janela
start "CheckPoint Frontend" cmd /c "node server.js & pause"

ping 127.0.0.1 -n 3 > nul

echo.
echo  ======================================================
echo    Sistema iniciado! Abra no navegador:               
echo                                                       
echo    http://localhost:8080/login.html                    
echo                                                       
echo    Logins de demo (senha: taskhub123):                
echo      Lider    - Leonardo@taskhub.dev                  
echo      Executor - Marcelo@taskhub.dev                   
echo      QA       - Artur@taskhub.dev                     
echo  ======================================================
echo.

:: Abre o browser automaticamente
start "" "http://localhost:8080/login.html"

exit
