// Lida com login e geração do token JWT.

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { JWT_SECRET } = require('../middlewares/auth.middleware');

// Body: { email, password }

async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'E-mail e senha são obrigatórios.' });
    }

    const user = await db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    if (!user) {
      return res.status(401).json({ error: 'Usuário não encontrado.' });
    }

    if (!user.is_active) {
      return res.status(403).json({ error: 'Conta desativada. Contate o administrador.' });
    }

    const passwordOk = bcrypt.compareSync(password, user.password);
    if (!passwordOk) {
      return res.status(401).json({ error: 'Senha incorreta.' });
    }

    // Monta o payload do token — nunca inclua a senha aqui
    const payload = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      position: user.position,
      avatar: user.avatar,
    };

    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '8h' });

    res.json({
      token,
      user: payload,
    });
  } catch (err) {
    console.error('[AUTH] Erro no login:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
}

// Retorna os dados do usuário logado (extraídos do token pelo middleware).

function getMe(req, res) {
  res.json({ user: req.user });
}

module.exports = { login, getMe };
