// CRUD de tarefas + Duplo Check-In (executor e validador).
//
// Fluxo de status:
//   pending  →(executor-checkin)→  executor_done
//   executor_done  →(validator approve)→  approved
//   executor_done  →(validator return)→   returned  →(executor corrige)→  pending

const { v4: uuidv4 } = require('uuid');
const db = require('../database');

// Query base — inclui nomes de executor e validador
const BASE_QUERY = `
  SELECT
    t.*,
    u1.name   AS assignee_name,
    u1.avatar AS assignee_avatar,
    u1.position AS assignee_position,
    u2.name   AS validator_name,
    u2.avatar AS validator_avatar,
    u3.name   AS created_by_name
  FROM tasks t
  LEFT JOIN users u1 ON t.assignee_id  = u1.id
  LEFT JOIN users u2 ON t.validator_id = u2.id
  LEFT JOIN users u3 ON t.created_by   = u3.id
`;

// ─── GET /api/tasks ──────────────────────────────────────────────────────────
async function listTasks(req, res) {
  try {
    const { status, priority, assignee_id, validator_id, mine } = req.query;
    const conditions = [];
    const params = [];

    if (status)      { conditions.push('t.status = ?');       params.push(status); }
    if (priority)    { conditions.push('t.priority = ?');     params.push(priority); }
    if (assignee_id) { conditions.push('t.assignee_id = ?'); params.push(assignee_id); }
    if (validator_id){ conditions.push('t.validator_id = ?'); params.push(validator_id); }

    // Filtro "minhas": mostra onde o usuário é executor OU validador
    if (mine === 'true') {
      conditions.push('(t.assignee_id = ? OR t.validator_id = ?)');
      params.push(req.user.id, req.user.id);
    }

    // Membros só veem tarefas relacionadas a eles
    if (req.user.role === 'member' && mine !== 'false') {
      conditions.push('(t.assignee_id = ? OR t.validator_id = ?)');
      params.push(req.user.id, req.user.id);
    }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const tasks = await db.prepare(
      `${BASE_QUERY} ${where} ORDER BY
         CASE t.status
           WHEN 'returned'       THEN 1
           WHEN 'executor_done'  THEN 2
           WHEN 'pending'        THEN 3
           WHEN 'approved'       THEN 4
         END,
         t.due_date ASC`
    ).all(...params);

    res.json(tasks);
  } catch (err) {
    console.error('[TASKS] Erro ao listar:', err);
    res.status(500).json({ error: 'Erro ao listar tarefas' });
  }
}

// ─── GET /api/tasks/stats ────────────────────────────────────────────────────
async function getTaskStats(req, res) {
  try {
    // Se for membro, stats filtradas para ele
    const isLeader = req.user.role === 'leader';
    const filter = isLeader
      ? ''
      : `WHERE (assignee_id = '${req.user.id}' OR validator_id = '${req.user.id}')`;

    const stats = await db.prepare(`
      SELECT
        COUNT(*)                                                           AS total,
        SUM(CASE WHEN status = 'pending'       THEN 1 ELSE 0 END)         AS pending,
        SUM(CASE WHEN status = 'executor_done' THEN 1 ELSE 0 END)         AS executor_done,
        SUM(CASE WHEN status = 'approved'      THEN 1 ELSE 0 END)         AS approved,
        SUM(CASE WHEN status = 'returned'      THEN 1 ELSE 0 END)         AS returned,
        SUM(CASE WHEN due_date < date('now') AND status NOT IN ('approved') THEN 1 ELSE 0 END) AS overdue
      FROM tasks ${filter}
    `).get();

    res.json(stats);
  } catch (err) {
    console.error('[TASKS] Erro ao buscar stats:', err);
    res.status(500).json({ error: 'Erro ao buscar estatísticas' });
  }
}

// ─── GET /api/tasks/pending-validation ───────────────────────────────────────
// Lista tarefas onde o usuário logado é o validador e status = executor_done
async function listPendingValidation(req, res) {
  try {
    const tasks = await db.prepare(
      `${BASE_QUERY}
       WHERE t.validator_id = ? AND t.status = 'executor_done'
       ORDER BY t.executor_checkin_at ASC`
    ).all(req.user.id);

    res.json(tasks);
  } catch (err) {
    console.error('[TASKS] Erro ao listar pendentes de validação:', err);
    res.status(500).json({ error: 'Erro ao listar tarefas pendentes de validação' });
  }
}

// ─── GET /api/tasks/:id ──────────────────────────────────────────────────────
async function getTask(req, res) {
  try {
    const task = await db.prepare(`${BASE_QUERY} WHERE t.id = ?`).get(req.params.id);

    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    const comments = await db.prepare(`
      SELECT tc.*, u.name AS author_name, u.avatar AS author_avatar
      FROM task_comments tc
      JOIN users u ON tc.user_id = u.id
      WHERE tc.task_id = ?
      ORDER BY tc.created_at ASC
    `).all(task.id);

    res.json({ ...task, comments });
  } catch (err) {
    console.error('[TASKS] Erro ao obter tarefa:', err);
    res.status(500).json({ error: 'Erro ao obter tarefa' });
  }
}

// ─── POST /api/tasks ─────────────────────────────────────────────────────────
// Somente líder cria tarefas. Deve informar executor (assignee_id) e validador (validator_id).
async function createTask(req, res) {
  try {
    const {
      assignee_id, validator_id,
      title, description,
      priority = 'medium',
      due_date,
    } = req.body;

    if (!title)        return res.status(400).json({ error: 'O título da tarefa é obrigatório.' });
    if (!assignee_id)  return res.status(400).json({ error: 'O executor (assignee_id) é obrigatório.' });
    if (!validator_id) return res.status(400).json({ error: 'O validador (validator_id) é obrigatório.' });
    if (assignee_id === validator_id) {
      return res.status(400).json({ error: 'O executor e o validador não podem ser a mesma pessoa.' });
    }

    const id = 't-' + uuidv4().slice(0, 8);

    await db.prepare(`
      INSERT INTO tasks
        (id, assignee_id, validator_id, created_by, title, description, priority, status, due_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)
    `).run(id, assignee_id, validator_id, req.user.id, title, description ?? null, priority, due_date ?? null);

    const task = await db.prepare(`${BASE_QUERY} WHERE t.id = ?`).get(id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'task_created', data: task });
    }

    res.status(201).json(task);
  } catch (err) {
    console.error('[TASKS] Erro ao criar tarefa:', err);
    res.status(500).json({ error: 'Erro ao criar tarefa' });
  }
}

// ─── PATCH /api/tasks/:id ────────────────────────────────────────────────────
// Líder pode editar campos descritivos enquanto tarefa está em 'pending' ou 'returned'.
async function updateTask(req, res) {
  try {
    const { id } = req.params;
    const task = await db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    if (req.user.role !== 'leader') {
      return res.status(403).json({ error: 'Apenas o líder pode editar tarefas diretamente.' });
    }

    const { title, description, priority, due_date, assignee_id, validator_id } = req.body;

    if (assignee_id && validator_id && assignee_id === validator_id) {
      return res.status(400).json({ error: 'O executor e o validador não podem ser a mesma pessoa.' });
    }

    await db.prepare(`
      UPDATE tasks SET
        title        = COALESCE(?, title),
        description  = COALESCE(?, description),
        priority     = COALESCE(?, priority),
        due_date     = COALESCE(?, due_date),
        assignee_id  = COALESCE(?, assignee_id),
        validator_id = COALESCE(?, validator_id)
      WHERE id = ?
    `).run(
      title ?? null, description ?? null, priority ?? null,
      due_date ?? null, assignee_id ?? null, validator_id ?? null,
      id
    );

    const updated = await db.prepare(`${BASE_QUERY} WHERE t.id = ?`).get(id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'task_updated', data: updated });
    }

    res.json(updated);
  } catch (err) {
    console.error('[TASKS] Erro ao atualizar tarefa:', err);
    res.status(500).json({ error: 'Erro ao atualizar tarefa' });
  }
}

// ─── DELETE /api/tasks/:id ───────────────────────────────────────────────────
async function deleteTask(req, res) {
  try {
    const task = await db.prepare('SELECT id FROM tasks WHERE id = ?').get(req.params.id);
    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    await db.prepare('DELETE FROM task_comments WHERE task_id = ?').run(req.params.id);
    await db.prepare('DELETE FROM tasks WHERE id = ?').run(req.params.id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'task_deleted', data: { id: req.params.id } });
    }

    res.json({ message: 'Tarefa removida.' });
  } catch (err) {
    console.error('[TASKS] Erro ao remover tarefa:', err);
    res.status(500).json({ error: 'Erro ao remover tarefa' });
  }
}

// ─── POST /api/tasks/:id/executor-checkin ────────────────────────────────────
// O executor (assignee) marca que concluiu a tarefa e escreve uma nota obrigatória.
async function executorCheckIn(req, res) {
  try {
    const { id } = req.params;
    const { note } = req.body;

    if (!note?.trim()) {
      return res.status(400).json({ error: 'A nota do check-in é obrigatória.' });
    }

    const task = await db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    // Apenas o executor pode fazer este check-in
    if (task.assignee_id !== req.user.id && req.user.role !== 'leader') {
      return res.status(403).json({ error: 'Apenas o executor da tarefa pode fazer o check-in de conclusão.' });
    }

    // Só é permitido nos status: pending ou returned
    if (!['pending', 'returned'].includes(task.status)) {
      return res.status(400).json({
        error: `Não é possível fazer check-in de executor em uma tarefa com status "${task.status}".`
      });
    }

    const now = new Date().toISOString();

    await db.prepare(`
      UPDATE tasks SET
        status                = 'executor_done',
        executor_checkin_at   = ?,
        executor_checkin_note = ?,
        -- Limpa decisão anterior (caso seja re-submissão após devolução)
        validator_checkin_at   = NULL,
        validator_checkin_note = NULL,
        validator_decision     = NULL
      WHERE id = ?
    `).run(now, note.trim(), id);

    // Registra no histórico
    await db.prepare(`
      INSERT INTO task_comments (id, task_id, user_id, content, type)
      VALUES (?, ?, ?, ?, 'checkin_exec')
    `).run(uuidv4(), id, req.user.id, note.trim());

    const updated = await db.prepare(`${BASE_QUERY} WHERE t.id = ?`).get(id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'checkin_executor', data: updated });
    }

    res.json(updated);
  } catch (err) {
    console.error('[TASKS] Erro no executor check-in:', err);
    res.status(500).json({ error: 'Erro ao registrar check-in do executor' });
  }
}

// ─── POST /api/tasks/:id/validator-checkin ───────────────────────────────────
// O validador aprova ou devolve a tarefa com uma nota obrigatória.
async function validatorCheckIn(req, res) {
  try {
    const { id } = req.params;
    const { decision, note } = req.body; // decision: 'approved' | 'returned'

    if (!note?.trim()) {
      return res.status(400).json({ error: 'A nota do check-in é obrigatória.' });
    }

    if (!['approved', 'returned'].includes(decision)) {
      return res.status(400).json({ error: 'A decisão deve ser "approved" ou "returned".' });
    }

    const task = await db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    // Apenas o validador designado (ou o líder) pode validar
    if (task.validator_id !== req.user.id && req.user.role !== 'leader') {
      return res.status(403).json({ error: 'Apenas o validador da tarefa pode fazer o check-in de validação.' });
    }

    // Só faz sentido quando o executor já fez o check-in
    if (task.status !== 'executor_done') {
      return res.status(400).json({
        error: `O validador só pode agir após o check-in do executor (status atual: "${task.status}").`
      });
    }

    const now = new Date().toISOString();

    // Se devolvida: volta para 'pending' e incrementa o contador de ciclos
    const newStatus = decision === 'approved' ? 'approved' : 'returned';
    const completedAt = decision === 'approved' ? now : null;
    const returnCount = decision === 'returned' ? task.return_count + 1 : task.return_count;

    await db.prepare(`
      UPDATE tasks SET
        status                 = ?,
        validator_checkin_at   = ?,
        validator_checkin_note = ?,
        validator_decision     = ?,
        return_count           = ?,
        completed_at           = COALESCE(?, completed_at)
      WHERE id = ?
    `).run(newStatus, now, note.trim(), decision, returnCount, completedAt, id);

    // Se devolvida, volta para pending depois de um breve delay lógico
    if (decision === 'returned') {
      await db.prepare(`UPDATE tasks SET status = 'pending' WHERE id = ?`).run(id);
    }

    // Registra no histórico
    const commentType = decision === 'approved' ? 'checkin_val_ok' : 'checkin_val_return';
    await db.prepare(`
      INSERT INTO task_comments (id, task_id, user_id, content, type)
      VALUES (?, ?, ?, ?, ?)
    `).run(uuidv4(), id, req.user.id, note.trim(), commentType);

    const updated = await db.prepare(`${BASE_QUERY} WHERE t.id = ?`).get(id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'checkin_validator', data: { task: updated, decision } });
    }

    res.json(updated);
  } catch (err) {
    console.error('[TASKS] Erro no validator check-in:', err);
    res.status(500).json({ error: 'Erro ao registrar check-in do validador' });
  }
}

// ─── POST /api/tasks/:id/comments ───────────────────────────────────────────
async function addComment(req, res) {
  try {
    const { content } = req.body;

    if (!content?.trim()) {
      return res.status(400).json({ error: 'O comentário não pode estar vazio.' });
    }

    const task = await db.prepare('SELECT id FROM tasks WHERE id = ?').get(req.params.id);
    if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });

    const id = uuidv4();
    await db.prepare(
      'INSERT INTO task_comments (id, task_id, user_id, content, type) VALUES (?, ?, ?, ?, ?)'
    ).run(id, req.params.id, req.user.id, content.trim(), 'comment');

    const comment = await db.prepare(`
      SELECT tc.*, u.name AS author_name, u.avatar AS author_avatar
      FROM task_comments tc
      JOIN users u ON tc.user_id = u.id
      WHERE tc.id = ?
    `).get(id);

    res.status(201).json(comment);
  } catch (err) {
    console.error('[TASKS] Erro ao adicionar comentário:', err);
    res.status(500).json({ error: 'Erro ao adicionar comentário' });
  }
}

module.exports = {
  listTasks,
  getTaskStats,
  listPendingValidation,
  getTask,
  createTask,
  updateTask,
  deleteTask,
  executorCheckIn,
  validatorCheckIn,
  addComment,
};
