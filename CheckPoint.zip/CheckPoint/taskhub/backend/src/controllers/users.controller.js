// Listagem e gerenciamento de usuários.

const db   = require('../database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

// GET /api/users — lista todos os membros ativos (usado para popular selects)
async function listUsers(req, res) {
  try {
    const users = await db.prepare(
      `SELECT id, name, email, role, position, avatar FROM users WHERE is_active = 1 ORDER BY name ASC`
    ).all();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao listar usuários' });
  }
}

// GET /api/users/:id — perfil de um usuário + métricas de check-in
async function getUser(req, res) {
  try {
    const user = await db.prepare(
      `SELECT id, name, email, role, position, avatar FROM users WHERE id = ?`
    ).get(req.params.id);

    if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });

    // Métricas de check-in como executor
    const execStats = await db.prepare(`
      SELECT
        COUNT(*)                                          AS total_assigned,
        SUM(CASE WHEN status = 'approved'  THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN status = 'pending'   THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN status = 'executor_done' THEN 1 ELSE 0 END) AS awaiting_validation,
        SUM(return_count)                                 AS total_returns
      FROM tasks WHERE assignee_id = ?
    `).get(user.id);

    // Taxa de aprovação no primeiro check-in
    const total = execStats.approved + execStats.total_returns;
    const approvalRate = total > 0
      ? Math.round((execStats.approved / (execStats.approved + execStats.total_returns)) * 100)
      : 100;

    res.json({ ...user, stats: { ...execStats, approval_rate: approvalRate } });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao obter usuário' });
  }
}

// POST /api/users — criar novo membro (somente líder)
async function createUser(req, res) {
  try {
    const { name, email, password, role = 'member', position, avatar } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Nome, e-mail e senha são obrigatórios.' });
    }

    const exists = await db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (exists) return res.status(400).json({ error: 'E-mail já cadastrado.' });

    const id   = 'u-' + uuidv4().slice(0, 8);
    const hash = bcrypt.hashSync(password, 10);

    await db.prepare(`
      INSERT INTO users (id, name, email, password, role, position, avatar)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, email, hash, role, position ?? null, avatar ?? name[0].toUpperCase());

    const user = await db.prepare('SELECT id, name, email, role, position, avatar FROM users WHERE id = ?').get(id);
    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao criar usuário' });
  }
}

// PATCH /api/users/:id/toggle — ativar/desativar (somente líder)
async function toggleUser(req, res) {
  try {
    const user = await db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });
    if (user.role === 'leader') return res.status(400).json({ error: 'Não é possível desativar o líder.' });

    await db.prepare('UPDATE users SET is_active = ? WHERE id = ?').run(user.is_active ? 0 : 1, user.id);
    res.json({ message: `Usuário ${user.is_active ? 'desativado' : 'ativado'}.` });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao alterar status do usuário' });
  }
}

module.exports = { listUsers, getUser, createUser, toggleUser };
