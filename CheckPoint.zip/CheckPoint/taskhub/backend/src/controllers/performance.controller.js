// Ranking de desempenho da equipe baseado em check-ins.

const db = require('../database');

// GET /api/performance/ranking
// Retorna membros ordenados por taxa de aprovação no primeiro check-in
async function getRanking(req, res) {
  try {
    const members = await db.prepare(`
      SELECT
        u.id,
        u.name,
        u.avatar,
        u.position,
        COUNT(t.id)                                          AS total_tasks,
        SUM(CASE WHEN t.status = 'approved'     THEN 1 ELSE 0 END) AS approved,
        SUM(CASE WHEN t.status = 'pending'
                  OR t.status = 'executor_done' THEN 1 ELSE 0 END) AS in_progress,
        SUM(t.return_count)                                  AS total_returns,
        ROUND(
          CASE
            WHEN SUM(CASE WHEN t.status = 'approved' THEN 1 ELSE 0 END) + SUM(t.return_count) = 0
            THEN 100.0
            ELSE (SUM(CASE WHEN t.status = 'approved' THEN 1 ELSE 0 END) * 100.0)
                 / (SUM(CASE WHEN t.status = 'approved' THEN 1 ELSE 0 END) + SUM(t.return_count))
          END
        , 1) AS approval_rate
      FROM users u
      LEFT JOIN tasks t ON t.assignee_id = u.id
      WHERE u.is_active = 1 AND u.role = 'member'
      GROUP BY u.id
      ORDER BY approval_rate DESC, approved DESC
    `).all();

    res.json(members);
  } catch (err) {
    console.error('[PERF] Erro ao buscar ranking:', err);
    res.status(500).json({ error: 'Erro ao buscar ranking' });
  }
}

// GET /api/performance/weekly
// Histórico semanal da equipe para o gráfico do dashboard
async function getWeeklyStats(req, res) {
  try {
    const rows = await db.prepare(`
      SELECT
        week_start,
        SUM(tasks_done)     AS tasks_done,
        SUM(tasks_returned) AS tasks_returned,
        ROUND(AVG(approval_rate), 1) AS avg_approval_rate
      FROM performance_logs
      WHERE week_start >= date('now', '-28 days')
      GROUP BY week_start
      ORDER BY week_start ASC
    `).all();

    res.json(rows);
  } catch (err) {
    console.error('[PERF] Erro ao buscar stats semanais:', err);
    res.status(500).json({ error: 'Erro ao buscar estatísticas semanais' });
  }
}

module.exports = { getRanking, getWeeklyStats };