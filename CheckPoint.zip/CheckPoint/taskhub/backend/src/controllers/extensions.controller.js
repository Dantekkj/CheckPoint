// Controlador de Ramais e Mensagens por Ramal (sistema de comunicação interna).

const db = require('../database');
const { v4: uuidv4 } = require('uuid');

// GET /api/extensions — lista todos os ramais
async function listExtensions(req, res) {
  try {
    const exts = await db.prepare(`
      SELECT e.*, u.name, u.avatar, u.role, u.position
      FROM extensions e
      JOIN users u ON e.user_id = u.id
      ORDER BY e.extension_number ASC
    `).all();
    res.json(exts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar ramais' });
  }
}

// POST /api/extensions/assign — atribui ramal ao usuário logado
async function assignExtension(req, res) {
  try {
    const userId = req.user.id;

    // Verifica se já tem ramal
    const existing = await db.prepare('SELECT * FROM extensions WHERE user_id = ?').get(userId);
    if (existing) return res.json(existing);

    // Gera próximo número de ramal disponível a partir de 100
    const last = await db.prepare(
      'SELECT extension_number FROM extensions ORDER BY CAST(extension_number AS INTEGER) DESC LIMIT 1'
    ).get();
    const nextNum = last ? String(parseInt(last.extension_number) + 1).padStart(3, '0') : '100';

    const id = 'ext-' + uuidv4().slice(0, 8);
    await db.prepare('INSERT INTO extensions (id, user_id, extension_number) VALUES (?, ?, ?)')
      .run(id, userId, nextNum);

    const ext = await db.prepare('SELECT * FROM extensions WHERE id = ?').get(id);
    res.status(201).json(ext);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atribuir ramal' });
  }
}

// GET /api/extensions/messages — conversas do usuário logado
async function listConversations(req, res) {
  try {
    const userId = req.user.id;

    // Retorna a última mensagem de cada conversa agrupada por parceiro
    const convs = await db.prepare(`
      SELECT
        CASE WHEN from_user_id = ? THEN to_user_id ELSE from_user_id END AS partner_id,
        MAX(created_at) AS last_at,
        SUM(CASE WHEN to_user_id = ? AND is_read = 0 THEN 1 ELSE 0 END) AS unread_count
      FROM extension_messages
      WHERE from_user_id = ? OR to_user_id = ?
      GROUP BY partner_id
      ORDER BY last_at DESC
    `).all(userId, userId, userId, userId);

    // Enriquece com dados dos parceiros e última mensagem
    const enriched = await Promise.all(convs.map(async (c) => {
      const partner = await db.prepare(
        `SELECT u.id, u.name, u.avatar, e.extension_number
         FROM users u
         LEFT JOIN extensions e ON e.user_id = u.id
         WHERE u.id = ?`
      ).get(c.partner_id);

      const lastMsg = await db.prepare(`
        SELECT content, from_user_id FROM extension_messages
        WHERE (from_user_id = ? AND to_user_id = ?) OR (from_user_id = ? AND to_user_id = ?)
        ORDER BY created_at DESC LIMIT 1
      `).get(userId, c.partner_id, c.partner_id, userId);

      return { ...c, partner, last_message: lastMsg };
    }));

    res.json(enriched);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar conversas' });
  }
}

// GET /api/extensions/messages/:partnerId — mensagens de uma conversa específica
async function getMessages(req, res) {
  try {
    const userId = req.user.id;
    const { partnerId } = req.params;

    const msgs = await db.prepare(`
      SELECT m.*, u.name AS from_name, u.avatar AS from_avatar
      FROM extension_messages m
      JOIN users u ON m.from_user_id = u.id
      WHERE (from_user_id = ? AND to_user_id = ?)
         OR (from_user_id = ? AND to_user_id = ?)
      ORDER BY created_at ASC
    `).all(userId, partnerId, partnerId, userId);

    // Marca as mensagens recebidas como lidas
    await db.prepare(
      'UPDATE extension_messages SET is_read = 1 WHERE to_user_id = ? AND from_user_id = ? AND is_read = 0'
    ).run(userId, partnerId);

    res.json(msgs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao obter mensagens' });
  }
}

// POST /api/extensions/messages — enviar mensagem por ramal
async function sendMessage(req, res) {
  try {
    const { to_user_id, content } = req.body;
    const fromUserId = req.user.id;

    if (!to_user_id || !content?.trim()) {
      return res.status(400).json({ error: 'Destinatário e conteúdo são obrigatórios.' });
    }

    // Obter ramais do remetente e destinatário
    const fromExt = await db.prepare('SELECT extension_number FROM extensions WHERE user_id = ?').get(fromUserId);
    const toExt = await db.prepare('SELECT extension_number FROM extensions WHERE user_id = ?').get(to_user_id);

    if (!fromExt) return res.status(400).json({ error: 'Você não possui ramal atribuído.' });
    if (!toExt) return res.status(400).json({ error: 'Destinatário não possui ramal.' });

    const id = 'msg-' + uuidv4().slice(0, 8);
    const now = new Date().toISOString();

    await db.prepare(`
      INSERT INTO extension_messages (id, from_ext, to_ext, from_user_id, to_user_id, content, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, fromExt.extension_number, toExt.extension_number, fromUserId, to_user_id, content.trim(), now);

    const msg = await db.prepare(`
      SELECT m.*, u.name AS from_name, u.avatar AS from_avatar
      FROM extension_messages m
      JOIN users u ON m.from_user_id = u.id
      WHERE m.id = ?
    `).get(id);

    // Broadcast via WebSocket para o destinatário
    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'new_extension_message', data: msg });
    }

    res.status(201).json(msg);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao enviar mensagem' });
  }
}

// GET /api/extensions/messages/unread — contagem de mensagens não lidas
async function getUnreadCount(req, res) {
  try {
    const userId = req.user.id;
    const result = await db.prepare(
      'SELECT COUNT(*) AS count FROM extension_messages WHERE to_user_id = ? AND is_read = 0'
    ).get(userId);
    res.json({ count: result.count });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao obter contagem' });
  }
}

module.exports = { listExtensions, assignExtension, listConversations, getMessages, sendMessage, getUnreadCount };
