// Controlador de Documentos com suporte a upload e assinaturas.

const db = require('../database');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

// Diretório de uploads
const UPLOADS_DIR = path.join(__dirname, '..', '..', '..', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Configuração do Multer para upload de arquivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `doc-${uuidv4().slice(0, 8)}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20 MB
  fileFilter: (req, file, cb) => {
    const allowed = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.png', '.jpg', '.jpeg'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error('Tipo de arquivo não permitido.'));
  }
});

// GET /api/documents — lista documentos do usuário logado
async function listDocuments(req, res) {
  try {
    const userId = req.user.id;
    const docs = await db.prepare(`
      SELECT d.*,
        s.name AS sender_name, s.avatar AS sender_avatar,
        r.name AS recipient_name, r.avatar AS recipient_avatar
      FROM documents d
      JOIN users s ON d.sender_id = s.id
      JOIN users r ON d.recipient_id = r.id
      WHERE d.sender_id = ? OR d.recipient_id = ?
      ORDER BY d.created_at DESC
    `).all(userId, userId);
    res.json(docs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar documentos' });
  }
}

// POST /api/documents — enviar novo documento com arquivo
async function createDocument(req, res) {
  try {
    const { title, description, recipient_id, doc_type, related_task_id, message, sender_signature } = req.body;
    const senderId = req.user.id;

    if (!title || !recipient_id) {
      return res.status(400).json({ error: 'Título e destinatário são obrigatórios.' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'É necessário anexar um arquivo.' });
    }

    const id = 'doc-' + uuidv4().slice(0, 8);
    const now = new Date().toISOString();

    await db.prepare(`
      INSERT INTO documents (id, title, description, file_name, file_path, file_size, file_type,
        sender_id, recipient_id, doc_type, related_task_id, message,
        sender_signed_at, sender_signature, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, title, description ?? null,
      req.file.originalname, req.file.filename, req.file.size, req.file.mimetype,
      senderId, recipient_id, doc_type ?? 'general', related_task_id ?? null, message ?? null,
      sender_signature ? now : null,
      sender_signature || null,
      'pending_signature',
      now
    );

    // Notifica via WebSocket
    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'document_sent', data: { id, title, sender_id: senderId, recipient_id } });
    }

    const doc = await db.prepare('SELECT * FROM documents WHERE id = ?').get(id);
    res.status(201).json(doc);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao criar documento' });
  }
}

// PATCH /api/documents/:id/sign — assinar documento
async function signDocument(req, res) {
  try {
    const { signature } = req.body;
    const userId = req.user.id;
    const doc = await db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Documento não encontrado.' });

    const now = new Date().toISOString();

    if (doc.sender_id === userId) {
      await db.prepare(
        'UPDATE documents SET sender_signature = ?, sender_signed_at = ? WHERE id = ?'
      ).run(signature || 'signed', now, doc.id);
    } else if (doc.recipient_id === userId) {
      await db.prepare(
        'UPDATE documents SET recipient_signature = ?, recipient_signed_at = ? WHERE id = ?'
      ).run(signature || 'signed', now, doc.id);
    } else {
      return res.status(403).json({ error: 'Você não está associado a este documento.' });
    }

    // Verifica se ambos assinaram e atualiza status
    const updated = await db.prepare('SELECT * FROM documents WHERE id = ?').get(doc.id);
    if (updated.sender_signature && updated.recipient_signature) {
      await db.prepare("UPDATE documents SET status = 'signed' WHERE id = ?").run(doc.id);
    }

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'document_signed', data: { id: doc.id } });
    }

    const final = await db.prepare('SELECT * FROM documents WHERE id = ?').get(doc.id);
    res.json(final);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao assinar documento' });
  }
}

// PATCH /api/documents/:id/reject — rejeitar documento
async function rejectDocument(req, res) {
  try {
    const userId = req.user.id;
    const doc = await db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Documento não encontrado.' });
    if (doc.recipient_id !== userId) return res.status(403).json({ error: 'Apenas o destinatário pode rejeitar.' });

    await db.prepare("UPDATE documents SET status = 'rejected' WHERE id = ?").run(doc.id);

    if (req.app.locals.broadcast) {
      req.app.locals.broadcast({ type: 'document_rejected', data: { id: doc.id } });
    }

    const final = await db.prepare('SELECT * FROM documents WHERE id = ?').get(doc.id);
    res.json(final);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao rejeitar documento' });
  }
}

// GET /api/documents/:id/download — download do arquivo
async function downloadDocument(req, res) {
  try {
    const userId = req.user.id;
    const doc = await db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Documento não encontrado.' });
    if (doc.sender_id !== userId && doc.recipient_id !== userId) {
      return res.status(403).json({ error: 'Acesso negado.' });
    }

    const filePath = path.join(UPLOADS_DIR, doc.file_path);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Arquivo não encontrado no servidor.' });

    res.download(filePath, doc.file_name);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao baixar documento' });
  }
}

module.exports = { listDocuments, createDocument, signDocument, rejectDocument, downloadDocument, upload };
