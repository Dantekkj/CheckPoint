// WebSocket — notificações em tempo real do CheckPoint.
// Eventos emitidos:
//   dashboard_snapshot  → enviado ao conectar (estado atual)
//   dashboard_tick      → a cada 15s (atualiza KPIs)
//   task_created        → nova tarefa criada pelo líder
//   task_updated        → tarefa editada
//   task_deleted        → tarefa removida
//   checkin_executor    → executor fez o 1º check-in
//   checkin_validator   → validador aprovou ou devolveu

const { WebSocketServer } = require('ws');
const db = require('./database');

function setupWebSocket(server) {
  const wss = new WebSocketServer({ server, path: '/ws' });

  function broadcast(payload) {
    const msg = JSON.stringify(payload);
    wss.clients.forEach((client) => {
      if (client.readyState === 1) client.send(msg);
    });
  }

  wss.on('connection', (ws) => {
    console.log(`[WS] Cliente conectado. Total: ${wss.clients.size}`);
    sendSnapshot(ws);

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === 'ping') ws.send(JSON.stringify({ type: 'pong' }));
      } catch { /* ignora mensagens malformadas */ }
    });

    ws.on('close', () => {
      console.log(`[WS] Cliente desconectado. Total: ${wss.clients.size}`);
    });
  });

  // Ticker automático a cada 15 segundos
  const ticker = setInterval(async () => {
    if (wss.clients.size === 0) return;
    try {
      const [stats, activity] = await Promise.all([getCheckInStats(), getRecentCheckIns()]);
      broadcast({
        type: 'dashboard_tick',
        data: { stats, activity },
      });
    } catch (err) {
      console.error('[WS] Erro no ticker:', err);
    }
  }, 15_000);

  wss.on('close', () => clearInterval(ticker));

  return broadcast;
}

// ─── Helpers de dados ────────────────────────────────────────────────────────

async function getCheckInStats() {
  return db.prepare(`
    SELECT
      COUNT(*)                                                            AS total,
      SUM(CASE WHEN status = 'pending'       THEN 1 ELSE 0 END)          AS pending,
      SUM(CASE WHEN status = 'executor_done' THEN 1 ELSE 0 END)          AS executor_done,
      SUM(CASE WHEN status = 'approved'      THEN 1 ELSE 0 END)          AS approved,
      SUM(CASE WHEN status = 'returned'      THEN 1 ELSE 0 END)          AS returned,
      SUM(CASE WHEN due_date < date('now') AND status != 'approved' THEN 1 ELSE 0 END) AS overdue
    FROM tasks
  `).get();
}

async function getRecentCheckIns() {
  // Últimos 6 eventos de check-in (executor ou validador)
  return db.prepare(`
    SELECT
      tc.content,
      tc.type,
      tc.created_at,
      u.name  AS author_name,
      u.avatar AS author_avatar,
      t.title AS task_title,
      t.id    AS task_id
    FROM task_comments tc
    JOIN users u ON tc.user_id = u.id
    JOIN tasks t ON tc.task_id = t.id
    WHERE tc.type IN ('checkin_exec', 'checkin_val_ok', 'checkin_val_return')
    ORDER BY tc.created_at DESC
    LIMIT 6
  `).all();
}

async function sendSnapshot(ws) {
  try {
    const [stats, activity] = await Promise.all([getCheckInStats(), getRecentCheckIns()]);
    const payload = JSON.stringify({
      type: 'dashboard_snapshot',
      data: { stats, activity },
    });
    if (ws.readyState === 1) ws.send(payload);
  } catch (err) {
    console.error('[WS] Erro ao enviar snapshot:', err);
  }
}

module.exports = { setupWebSocket };
