// Rotas de documentos

const router = require('express').Router();
const { requireAuth } = require('../middlewares/auth.middleware');
const ctrl = require('../controllers/documents.controller');

router.get('/',               requireAuth, ctrl.listDocuments);
router.post('/',              requireAuth, ctrl.upload.single('file'), ctrl.createDocument);
router.patch('/:id/sign',     requireAuth, ctrl.signDocument);
router.patch('/:id/reject',   requireAuth, ctrl.rejectDocument);
router.get('/:id/download',   requireAuth, ctrl.downloadDocument);

module.exports = router;
