// Rotas de tarefas — Duplo Check-In

const router = require('express').Router();
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const ctrl = require('../controllers/tasks.controller');

// Leitura: todos os autenticados
router.get('/',                    requireAuth, ctrl.listTasks);
router.get('/stats',               requireAuth, ctrl.getTaskStats);
router.get('/pending-validation',  requireAuth, ctrl.listPendingValidation);
router.get('/:id',                 requireAuth, ctrl.getTask);

// Criação e edição: somente líder
router.post('/',     requireAuth, requireRole('leader'), ctrl.createTask);
router.patch('/:id', requireAuth, requireRole('leader'), ctrl.updateTask);
router.delete('/:id',requireAuth, requireRole('leader'), ctrl.deleteTask);

// Check-ins: qualquer membro autenticado (a lógica de quem pode agir fica no controller)
router.post('/:id/executor-checkin',  requireAuth, ctrl.executorCheckIn);
router.post('/:id/validator-checkin', requireAuth, ctrl.validatorCheckIn);

// Comentários
router.post('/:id/comments', requireAuth, ctrl.addComment);

module.exports = router;
