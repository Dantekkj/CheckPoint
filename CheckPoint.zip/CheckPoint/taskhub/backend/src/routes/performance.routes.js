// Rotas de performance / ranking

const router = require('express').Router();
const { requireAuth } = require('../middlewares/auth.middleware');
const ctrl = require('../controllers/performance.controller');

router.get('/ranking', requireAuth, ctrl.getRanking);
router.get('/weekly',  requireAuth, ctrl.getWeeklyStats);

module.exports = router;
