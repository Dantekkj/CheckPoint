// Rotas de ramais e mensagens

const router = require('express').Router();
const { requireAuth } = require('../middlewares/auth.middleware');
const ctrl = require('../controllers/extensions.controller');

router.get('/',                    requireAuth, ctrl.listExtensions);
router.post('/assign',             requireAuth, ctrl.assignExtension);
// IMPORTANTE: /messages/unread DEVE vir antes de /messages/:partnerId
// Caso contrário, Express captura "unread" como partnerId
router.get('/messages/unread',     requireAuth, ctrl.getUnreadCount);
router.get('/messages',            requireAuth, ctrl.listConversations);
router.get('/messages/:partnerId', requireAuth, ctrl.getMessages);
router.post('/messages',           requireAuth, ctrl.sendMessage);

module.exports = router;
