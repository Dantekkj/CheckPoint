// Rotas de usuários

const router = require('express').Router();
const { requireAuth, requireRole } = require('../middlewares/auth.middleware');
const ctrl = require('../controllers/users.controller');

router.get('/',           requireAuth, ctrl.listUsers);
router.get('/:id',        requireAuth, ctrl.getUser);
router.post('/',          requireAuth, requireRole('leader'), ctrl.createUser);
router.patch('/:id/toggle', requireAuth, requireRole('leader'), ctrl.toggleUser);

module.exports = router;
