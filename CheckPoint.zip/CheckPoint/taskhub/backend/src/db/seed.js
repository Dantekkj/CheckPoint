// seed.js — Popula o banco com dados de demonstração para o CheckPoint.
// Simula uma equipe com tarefas em diferentes estágios do Duplo Check-In.
// Execute: node src/db/seed.js   (ou: npm run seed)

const bcrypt   = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db       = require('../database');
const { runMigrations } = require('./migrate');

const HASH = bcrypt.hashSync('taskhub123', 10);

async function insertOrSkip(table, data) {
  const cols = Object.keys(data).join(', ');
  const placeholders = Object.keys(data).map(() => '?').join(', ');
  const stmt = db.prepare(`INSERT OR IGNORE INTO ${table} (${cols}) VALUES (${placeholders})`);
  return await stmt.run(...Object.values(data));
}

function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function daysAgoISO(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
}

function mondayWeeksAgo(weeks) {
  const d = new Date();
  const day = d.getDay();
  d.setDate(d.getDate() - day + 1 - weeks * 7);
  return d.toISOString().slice(0, 10);
}

// ─── Usuários ───────────────────────────────────────────────────────────────
const USERS = [
  { id: 'u-lider', name: 'Leonardo Munhoz',    email: 'Leonardo@taskhub.dev', role: 'leader', position: 'Tech Lead',    avatar: 'LM' },
  { id: 'u-001',   name: 'Marcelo Nascimento', email: 'Marcelo@taskhub.dev',  role: 'member', position: 'Dev Backend',  avatar: 'MN' },
  { id: 'u-002',   name: 'Gabriel De Lima',    email: 'Gabriel@taskhub.dev',  role: 'member', position: 'Dev Frontend', avatar: 'GL' },
  { id: 'u-003',   name: 'Artur Taroco',       email: 'Artur@taskhub.dev',    role: 'member', position: 'QA Engineer',  avatar: 'AT' },
  { id: 'u-004',   name: 'Lucas Eduardo',      email: 'Lucas@taskhub.dev',    role: 'member', position: 'Dev Backend',  avatar: 'LE' },
  { id: 'u-005',   name: 'Jose Eduardo',       email: 'Jose@taskhub.dev',     role: 'member', position: 'UX Designer',  avatar: 'JE' },
];

// ─── Tarefas — vários estágios do duplo check-in ────────────────────────────
//
// status: pending | executor_done | approved | returned
//
// Leitura:
//   pending       → ninguém fez nada ainda (ou foi devolvida e voltou)
//   executor_done → executor fez o 1º check-in, aguarda validador
//   approved      → validador aprovou: tarefa concluída ✔
//   returned      → validador devolveu: executor deve corrigir

const TASKS = [
  // ── Aprovadas (ambos os check-ins concluídos) ─────────────────────────────
  {
    id: 't-001',
    assignee_id: 'u-001', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Modelagem do banco de dados',
    description: 'Definir entidades, relacionamentos e índices do schema principal.',
    priority: 'high', status: 'approved', due_date: daysAgo(50),
    executor_checkin_at: daysAgoISO(49), executor_checkin_note: 'Schema completo com todas as tabelas e foreign keys. Script de migration pronto.',
    validator_checkin_at: daysAgoISO(48), validator_checkin_note: 'Revisado e aprovado. Ótimo trabalho.', validator_decision: 'approved',
    return_count: 0, completed_at: daysAgoISO(48),
  },
  {
    id: 't-002',
    assignee_id: 'u-002', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Protótipo das telas no Figma',
    description: 'Criar wireframes e protótipo navegável de todas as telas.',
    priority: 'high', status: 'approved', due_date: daysAgo(44),
    executor_checkin_at: daysAgoISO(45), executor_checkin_note: 'Protótipo com 12 telas finalizado. Link no Figma compartilhado.',
    validator_checkin_at: daysAgoISO(44), validator_checkin_note: 'Aprovado após pequeno ajuste no fluxo de login.', validator_decision: 'approved',
    return_count: 0, completed_at: daysAgoISO(44),
  },
  {
    id: 't-003',
    assignee_id: 'u-001', validator_id: 'u-003', created_by: 'u-lider',
    title: 'API de autenticação JWT',
    description: 'Implementar login, geração de token e middleware de proteção de rotas.',
    priority: 'critical', status: 'approved', due_date: daysAgo(38),
    executor_checkin_at: daysAgoISO(39), executor_checkin_note: 'Login, refresh e revogação de token implementados com testes unitários.',
    validator_checkin_at: daysAgoISO(37), validator_checkin_note: 'Todos os testes passaram. Cobertura de 94%. Aprovado.', validator_decision: 'approved',
    return_count: 0, completed_at: daysAgoISO(37),
  },
  {
    id: 't-004',
    assignee_id: 'u-004', validator_id: 'u-001', created_by: 'u-lider',
    title: 'API de catálogo de produtos',
    description: 'CRUD de produtos com filtros, paginação e upload de imagem.',
    priority: 'high', status: 'approved', due_date: daysAgo(30),
    executor_checkin_at: daysAgoISO(31), executor_checkin_note: 'Endpoints documentados no Swagger. Paginação e filtros funcionando.',
    validator_checkin_at: daysAgoISO(30), validator_checkin_note: 'Testei 15 cenários, todos OK. Aprovado.', validator_decision: 'approved',
    return_count: 0, completed_at: daysAgoISO(30),
  },
  {
    id: 't-005',
    assignee_id: 'u-005', validator_id: 'u-002', created_by: 'u-lider',
    title: 'Design do sistema de checkout',
    description: 'UI completa do fluxo de checkout: endereço, pagamento e confirmação.',
    priority: 'high', status: 'approved', due_date: daysAgo(24),
    executor_checkin_at: daysAgoISO(25), executor_checkin_note: 'Todas as telas finalizadas com estados de loading e erro.',
    validator_checkin_at: daysAgoISO(23), validator_checkin_note: 'Consistência visual perfeita. Aprovado!', validator_decision: 'approved',
    return_count: 0, completed_at: daysAgoISO(23),
  },

  // ── Devolvida e re-feita (1 ciclo) ───────────────────────────────────────
  {
    id: 't-006',
    assignee_id: 'u-003', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Plano de testes da sprint 1',
    description: 'Criar casos de teste para os módulos de auth e catálogo.',
    priority: 'medium', status: 'approved', due_date: daysAgo(20),
    executor_checkin_at: daysAgoISO(18), executor_checkin_note: 'Plano de testes atualizado após feedback: adicionei cenários de edge case.',
    validator_checkin_at: daysAgoISO(17), validator_checkin_note: 'Agora está completo. Aprovado.', validator_decision: 'approved',
    return_count: 1, completed_at: daysAgoISO(17),
  },

  // ── Aguardando validação (executor fez check-in) ──────────────────────────
  {
    id: 't-007',
    assignee_id: 'u-002', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Tela de checkout (frontend)',
    description: 'Implementar a UI do checkout integrada com a API de pagamento.',
    priority: 'high', status: 'executor_done', due_date: daysAgo(-3),
    executor_checkin_at: daysAgoISO(1), executor_checkin_note: 'Tela integrada com a API. Testei nos browsers Chrome, Firefox e Safari.',
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-008',
    assignee_id: 'u-004', validator_id: 'u-001', created_by: 'u-lider',
    title: 'Módulo de cupons de desconto',
    description: 'Lógica de validação e aplicação de cupons no carrinho.',
    priority: 'medium', status: 'executor_done', due_date: daysAgo(-2),
    executor_checkin_at: daysAgoISO(0), executor_checkin_note: 'Cupons de percentual e valor fixo funcionando. Limite de uso e expiração OK.',
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-009',
    assignee_id: 'u-003', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Testes de performance da API',
    description: 'Rodar benchmarks nos endpoints críticos e documentar resultados.',
    priority: 'high', status: 'executor_done', due_date: daysAgo(-1),
    executor_checkin_at: daysAgoISO(0), executor_checkin_note: 'Relatório com k6 anexado. P99 < 200ms em todos os endpoints.',
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },

  // ── Devolvidas (aguardando correção do executor) ──────────────────────────
  {
    id: 't-010',
    assignee_id: 'u-001', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Painel administrativo — pedidos',
    description: 'Dashboard de pedidos com filtros, exportação CSV e detalhes do pedido.',
    priority: 'high', status: 'returned', due_date: daysAgo(-5),
    executor_checkin_at: daysAgoISO(2), executor_checkin_note: 'Painel criado com listagem e filtros. Export ainda não implementado.',
    validator_checkin_at: daysAgoISO(1), validator_checkin_note: 'A exportação CSV é obrigatória nesta entrega. Favor implementar e refazer o check-in.', validator_decision: 'returned',
    return_count: 1, completed_at: null,
  },

  // ── Pendentes (nenhum check-in ainda) ────────────────────────────────────
  {
    id: 't-011',
    assignee_id: 'u-005', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Redesign da página inicial',
    description: 'Atualizar hero section, seção de features e CTA conforme novo brand.',
    priority: 'medium', status: 'pending', due_date: daysAgo(-8),
    executor_checkin_at: null, executor_checkin_note: null,
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-012',
    assignee_id: 'u-002', validator_id: 'u-003', created_by: 'u-lider',
    title: 'Integração com sistema de frete',
    description: 'Consumir API dos Correios e calcular frete em tempo real no carrinho.',
    priority: 'medium', status: 'pending', due_date: daysAgo(-12),
    executor_checkin_at: null, executor_checkin_note: null,
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-013',
    assignee_id: 'u-001', validator_id: 'u-004', created_by: 'u-lider',
    title: 'API de relatórios de vendas',
    description: 'Endpoints para exportar relatórios de vendas por período e categoria.',
    priority: 'low', status: 'pending', due_date: daysAgo(-18),
    executor_checkin_at: null, executor_checkin_note: null,
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-014',
    assignee_id: 'u-004', validator_id: 'u-001', created_by: 'u-lider',
    title: 'Sistema de notificações por e-mail',
    description: 'Envio de e-mails transacionais: confirmação de pedido, envio, cancelamento.',
    priority: 'medium', status: 'pending', due_date: daysAgo(-15),
    executor_checkin_at: null, executor_checkin_note: null,
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
  {
    id: 't-015',
    assignee_id: 'u-003', validator_id: 'u-lider', created_by: 'u-lider',
    title: 'Testes de segurança (OWASP)',
    description: 'Checar vulnerabilidades OWASP Top 10 e corrigir findings críticos.',
    priority: 'high', status: 'pending', due_date: daysAgo(-20),
    executor_checkin_at: null, executor_checkin_note: null,
    validator_checkin_at: null, validator_checkin_note: null, validator_decision: null,
    return_count: 0, completed_at: null,
  },
];

// ─── Logs de performance (4 semanas) ─────────────────────────────────────────
const PERFORMANCE = [];
const MEMBERS = [
  { id: 'u-001', done: [3,2,3,2], returned: [0,1,0,0] },
  { id: 'u-002', done: [2,3,2,1], returned: [1,0,0,0] },
  { id: 'u-003', done: [3,2,3,2], returned: [0,0,1,0] },
  { id: 'u-004', done: [2,2,3,2], returned: [1,0,0,1] },
  { id: 'u-005', done: [1,2,2,1], returned: [0,0,1,0] },
];

for (const m of MEMBERS) {
  for (let w = 4; w >= 1; w--) {
    const done = m.done[4 - w];
    const ret  = m.returned[4 - w];
    const total = done + ret;
    PERFORMANCE.push({
      id: uuidv4(),
      user_id: m.id,
      week_start: mondayWeeksAgo(w),
      tasks_done: done,
      tasks_returned: ret,
      approval_rate: total > 0 ? Math.round((done / total) * 100) : 100,
    });
  }
}

async function runSeed(force = false) {
  // Só semeia se não houver usuários (ou se forçado via argumento)
  if (!force) {
    const count = await new Promise((resolve, reject) => {
      db.get('SELECT COUNT(*) AS c FROM users', (err, row) => {
        if (err) reject(err);
        else resolve(row ? row.c : 0);
      });
    });
    if (count > 0) {
      console.log('[SEED] Banco já possui dados. Pulando seed.');
      return;
    }
  }

  // Usuários
  for (const u of USERS) {
    await insertOrSkip('users', { ...u, password: HASH, is_active: 1 });
  }

  // Tarefas
  for (const t of TASKS) {
    await insertOrSkip('tasks', t);
  }

  // Performance
  for (const p of PERFORMANCE) {
    await insertOrSkip('performance_logs', p);
  }

  // Ramais (Extensions)
  const EXTENSIONS = [
    { id: 'ext-1', user_id: 'u-lider', extension_number: '100' },
    { id: 'ext-2', user_id: 'u-001',   extension_number: '101' },
    { id: 'ext-3', user_id: 'u-002',   extension_number: '102' },
    { id: 'ext-4', user_id: 'u-003',   extension_number: '103' },
    { id: 'ext-5', user_id: 'u-004',   extension_number: '104' },
    { id: 'ext-6', user_id: 'u-005',   extension_number: '105' },
  ];
  for (const e of EXTENSIONS) {
    await insertOrSkip('extensions', e);
  }

  // Mensagens
  const MESSAGES = [
    {
      id: uuidv4(), from_ext: '100', to_ext: '101',
      from_user_id: 'u-lider', to_user_id: 'u-001',
      content: 'Fala Marcelo, quando puder dá uma olhada naquele PR do banco de dados. Um abraço!',
      is_read: 0, created_at: daysAgoISO(0)
    },
    {
      id: uuidv4(), from_ext: '100', to_ext: '102',
      from_user_id: 'u-lider', to_user_id: 'u-002',
      content: 'Gabriel, o protótipo do Figma ficou excelente! Vou passar para a aprovação do cliente.',
      is_read: 0, created_at: daysAgoISO(0)
    },
    {
      id: uuidv4(), from_ext: '100', to_ext: '103',
      from_user_id: 'u-lider', to_user_id: 'u-003',
      content: 'Artur, já temos os relatórios dos testes de segurança?',
      is_read: 0, created_at: daysAgoISO(0)
    },
    {
      id: uuidv4(), from_ext: '100', to_ext: '104',
      from_user_id: 'u-lider', to_user_id: 'u-004',
      content: 'Lucas, como estamos no módulo de cupons?',
      is_read: 0, created_at: daysAgoISO(0)
    },
    {
      id: uuidv4(), from_ext: '100', to_ext: '105',
      from_user_id: 'u-lider', to_user_id: 'u-005',
      content: 'José, a nova identidade visual já tem data?',
      is_read: 0, created_at: daysAgoISO(0)
    },
  ];
  for (const m of MESSAGES) {
    await insertOrSkip('extension_messages', m);
  }


  console.log('[SEED] Banco populado com sucesso!');
  console.log('');
  console.log('Usuários disponíveis para login (senha: taskhub123):');
  console.log('  Líder  → Leonardo@taskhub.dev');
  USERS.filter(u => u.role === 'member').forEach(u => {
    console.log(`  Membro → ${u.email}`);
  });
}

// Permite rodar diretamente: node src/db/seed.js [--force]
if (require.main === module) {
  const force = process.argv.includes('--force');
  (async () => {
    await runMigrations();
    await runSeed(force);
    process.exit(0);
  })();
}

module.exports = { runSeed };