// Cria todas as tabelas do banco caso não existam.
// Rodado automaticamente na inicialização do app.

const db = require('../database');

async function runMigrations() {
  const migrations = [
    // Tabela de usuários (líder e membros)
    `CREATE TABLE IF NOT EXISTS users (
      id          TEXT PRIMARY KEY,
      name        TEXT NOT NULL,
      email       TEXT NOT NULL UNIQUE,
      password    TEXT NOT NULL,
      role        TEXT NOT NULL DEFAULT 'member',
      position    TEXT,
      avatar      TEXT,
      is_active   INTEGER NOT NULL DEFAULT 1,
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Tarefas com suporte a Duplo Check-In
    // status: pending | executor_done | approved | returned
    `CREATE TABLE IF NOT EXISTS tasks (
      id                      TEXT PRIMARY KEY,
      assignee_id             TEXT REFERENCES users(id),   -- executor
      validator_id            TEXT REFERENCES users(id),   -- quem valida
      created_by              TEXT REFERENCES users(id),
      title                   TEXT NOT NULL,
      description             TEXT,
      priority                TEXT NOT NULL DEFAULT 'medium',
      status                  TEXT NOT NULL DEFAULT 'pending',
      due_date                TEXT,
      -- 1º Check-In: executor marca que terminou
      executor_checkin_at     TEXT,
      executor_checkin_note   TEXT,
      -- 2º Check-In: validador confirma ou devolve
      validator_checkin_at    TEXT,
      validator_checkin_note  TEXT,
      validator_decision      TEXT,   -- 'approved' | 'returned'
      -- Ciclos de devolução (retorna a pending)
      return_count            INTEGER NOT NULL DEFAULT 0,
      completed_at            TEXT,
      created_at              TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Comentários / histórico de uma tarefa
    `CREATE TABLE IF NOT EXISTS task_comments (
      id         TEXT PRIMARY KEY,
      task_id    TEXT NOT NULL REFERENCES tasks(id),
      user_id    TEXT NOT NULL REFERENCES users(id),
      content    TEXT NOT NULL,
      type       TEXT NOT NULL DEFAULT 'comment', -- 'comment' | 'checkin_exec' | 'checkin_val'
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Logs de performance semanal
    `CREATE TABLE IF NOT EXISTS performance_logs (
      id               TEXT PRIMARY KEY,
      user_id          TEXT NOT NULL REFERENCES users(id),
      week_start       TEXT NOT NULL,
      tasks_done       INTEGER DEFAULT 0,
      tasks_returned   INTEGER DEFAULT 0,
      approval_rate    REAL DEFAULT 0,
      created_at       TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Tabela de documentos (PDF, Word, etc.) com assinaturas
    `CREATE TABLE IF NOT EXISTS documents (
      id              TEXT PRIMARY KEY,
      title           TEXT NOT NULL,
      description     TEXT,
      file_name       TEXT NOT NULL,
      file_path       TEXT NOT NULL,
      file_size       INTEGER,
      file_type       TEXT NOT NULL,
      sender_id       TEXT NOT NULL REFERENCES users(id),
      recipient_id    TEXT NOT NULL REFERENCES users(id),
      doc_type        TEXT NOT NULL DEFAULT 'general',
      related_task_id TEXT REFERENCES tasks(id),
      status          TEXT NOT NULL DEFAULT 'pending_signature',
      message         TEXT,
      sender_signed_at    TEXT,
      sender_signature    TEXT,
      recipient_signed_at TEXT,
      recipient_signature TEXT,
      created_at      TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Tabela de ramais (sistema de telefonia interna)
    `CREATE TABLE IF NOT EXISTS extensions (
      id               TEXT PRIMARY KEY,
      user_id          TEXT NOT NULL REFERENCES users(id),
      extension_number TEXT NOT NULL UNIQUE,
      created_at       TEXT NOT NULL DEFAULT (datetime('now'))
    )`,

    // Mensagens por ramal (chat interno)
    `CREATE TABLE IF NOT EXISTS extension_messages (
      id           TEXT PRIMARY KEY,
      from_ext     TEXT NOT NULL,
      to_ext       TEXT NOT NULL,
      from_user_id TEXT NOT NULL REFERENCES users(id),
      to_user_id   TEXT NOT NULL REFERENCES users(id),
      content      TEXT NOT NULL,
      is_read      INTEGER NOT NULL DEFAULT 0,
      created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    )`
  ];

  for (const migration of migrations) {
    await new Promise((resolve, reject) => {
      db.run(migration, (err) => {
        if (err) {
          console.error('[DB] Erro na migration:', err);
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  console.log('[DB] Migrations executadas com sucesso.');
}

module.exports = { runMigrations };
