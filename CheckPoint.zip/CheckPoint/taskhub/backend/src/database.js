// Cria e exporta a conexão com o banco SQLite.
// Usando sqlite3 com wrappers que retornam Promessas para facilitar async/await.

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// O arquivo do banco fica na raiz do backend
const DB_PATH = path.join(__dirname, '..', '..', 'taskhub.db');

const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('[DB] Erro ao conectar:', err.message);
  } else {
    console.log('[DB] Conectado ao SQLite');
  }
});

// Configurações do SQLite
db.run("PRAGMA journal_mode = WAL");
db.run("PRAGMA foreign_keys = ON");

// Wrapper para exec (para migrations)
const _nativeExec = db.exec.bind(db);
db.exec = function(sql) {
  return new Promise((resolve, reject) => {
    _nativeExec(sql, function(err) {
      if (err) reject(err);
      else resolve();
    });
  });
};

// Wrapper para prepare - retorna um objeto com métodos async
db.prepare = function(sql) {
  const that = this;
  return {
    get: (...params) => new Promise((resolve, reject) => {
      that.get(sql, params, function(err, row) {
        if (err) reject(err);
        else resolve(row);
      });
    }),
    
    all: (...params) => new Promise((resolve, reject) => {
      that.all(sql, params, function(err, rows) {
        if (err) reject(err);
        else resolve(rows || []);
      });
    }),
    
    run: (...params) => new Promise((resolve, reject) => {
      that.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ lastID: this.lastID, changes: this.changes });
      });
    })
  };
};

module.exports = db;
