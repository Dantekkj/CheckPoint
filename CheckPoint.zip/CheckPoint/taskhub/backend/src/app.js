// CheckPoint — Inicialização do servidor
// 1. Migrations (cria tabelas)
// 2. Express + rotas
// 3. WebSocket acoplado ao mesmo HTTP server

const http    = require('http');
const express = require('express');
const cors    = require('cors');
const morgan  = require('morgan');

const { runMigrations }  = require('./db/migrate');
const { runSeed }        = require('./db/seed');
const { setupWebSocket } = require('./websocket');
const { errorHandler }   = require('./middlewares/error.middleware');

const authRoutes        = require('./routes/auth.routes');
const usersRoutes       = require('./routes/users.routes');
const tasksRoutes       = require('./routes/tasks.routes');
const performanceRoutes = require('./routes/performance.routes');
const documentsRoutes  = require('./routes/documents.routes');
const extensionsRoutes = require('./routes/extensions.routes');

const PORT = process.env.PORT || 3000;

async function startServer() {
  await runMigrations();
  await runSeed();   // Popula apenas se o banco estiver vazio

  const app = express();

  app.use(cors({ origin: '*' }));
  app.use(express.json());
  app.use(morgan('dev'));

  // Permite enviar o token JWT via query string ?token=... (necessário para links de download)
  app.use((req, _res, next) => {
    if (!req.headers['authorization'] && req.query.token) {
      req.headers['authorization'] = `Bearer ${req.query.token}`;
    }
    next();
  });

  app.use('/api/auth',        authRoutes);
  app.use('/api/users',       usersRoutes);
  app.use('/api/tasks',       tasksRoutes);
  app.use('/api/performance', performanceRoutes);
  app.use('/api/documents',   documentsRoutes);
  app.use('/api/extensions',  extensionsRoutes);

  // Serve arquivos de upload estaticamente
  const path = require('path');
  app.use('/uploads', express.static(path.join(__dirname, '..', '..', 'uploads')));

  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  app.use((req, res) => {
    res.status(404).json({ error: `Rota ${req.method} ${req.path} não encontrada.` });
  });

  app.use(errorHandler);

  const server = http.createServer(app);
  const broadcast = setupWebSocket(server);
  app.locals.broadcast = broadcast;

  server.listen(PORT, () => {
    console.log('');
    console.log('   ██████╗██╗  ██╗███████╗ ██████╗██╗  ██╗██████╗  ██████╗ ██╗███╗   ██╗████████╗');
    console.log('  ██╔════╝██║  ██║██╔════╝██╔════╝██║ ██╔╝██╔══██╗██╔═══██╗██║████╗  ██║╚══██╔══╝');
    console.log('  ██║     ███████║█████╗  ██║     █████╔╝ ██████╔╝██║   ██║██║██╔██╗ ██║   ██║   ');
    console.log('  ██║     ██╔══██║██╔══╝  ██║     ██╔═██╗ ██╔═══╝ ██║   ██║██║██║╚██╗██║   ██║   ');
    console.log('  ╚██████╗██║  ██║███████╗╚██████╗██║  ██╗██║     ╚██████╔╝██║██║ ╚████║   ██║   ');
    console.log('   ╚═════╝╚═╝  ╚═╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝╚═╝  ╚═══╝   ╚═╝   ');
    console.log('');
    console.log(`  Sistema de Tarefas com Duplo Check-In`);
    console.log('');
    console.log(`  API       → http://localhost:${PORT}/api`);
    console.log(`  WebSocket → ws://localhost:${PORT}/ws`);
    console.log(`  Health    → http://localhost:${PORT}/api/health`);
    console.log('');
    console.log('  Logins de demonstração (senha: taskhub123):');
    console.log('    Líder  → Leonardo@taskhub.dev');
    console.log('    Membro → Marcelo@taskhub.dev');
    console.log('    Membro → Gabriel@taskhub.dev');
    console.log('');
  });
}

startServer().catch(err => {
  console.error('[ERRO] Falha ao iniciar servidor:', err);
  process.exit(1);
});
