// team.js — Ranking da equipe por taxa de aprovação no primeiro check-in.

(function () {
  if (!Auth.guard()) return;
  Auth.renderHeader();

  async function loadRanking() {
    try {
      const members = await API.get('/performance/ranking');
      renderRanking(members);
    } catch (err) {
      document.getElementById('team-tbody').innerHTML =
        `<tr><td colspan="6" class="px-4 py-8 text-center text-red-400 text-sm">Erro: ${err.message}</td></tr>`;
    }
  }

  function renderRanking(members) {
    const tbody = document.getElementById('team-tbody');
    if (!members || members.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="px-4 py-8 text-center text-slate-500">Nenhum membro encontrado.</td></tr>';
      return;
    }

    const medals = ['🥇', '🥈', '🥉'];

    tbody.innerHTML = members.map((m, i) => {
      const rate = m.approval_rate ?? 0;

      // Cor da barra e badge por taxa
      let barColor, badgeClass;
      if (rate >= 90) { barColor = '#34d399'; badgeClass = 'text-green-400 bg-green-900/30 border-green-700'; }
      else if (rate >= 70) { barColor = '#818cf8'; badgeClass = 'text-indigo-400 bg-indigo-900/30 border-indigo-700'; }
      else if (rate >= 50) { barColor = '#fbbf24'; badgeClass = 'text-amber-400 bg-amber-900/30 border-amber-700'; }
      else { barColor = '#f87171'; badgeClass = 'text-red-400 bg-red-900/30 border-red-700'; }

      const medal = medals[i] || (i + 1 + 'º');

      return `
        <tr class="border-b border-slate-800/50 hover:bg-slate-800/20 transition">
          <td class="px-4 py-3 text-lg">${medal}</td>
          <td class="px-4 py-3">
            <div class="flex items-center gap-3">
              <div class="w-8 h-8 bg-indigo-800 rounded-full flex items-center justify-center text-sm font-bold text-indigo-300 flex-shrink-0">
                ${esc(m.avatar || m.name?.[0] || '?')}
              </div>
              <div>
                <p class="text-sm font-medium text-white">${esc(m.name)}</p>
                <p class="text-xs text-slate-500">${esc(m.position || '—')}</p>
              </div>
            </div>
          </td>
          <td class="px-4 py-3 text-sm text-slate-400">${esc(m.position || '—')}</td>
          <td class="px-4 py-3">
            <span class="text-sm font-semibold text-green-400">${m.approved ?? 0}</span>
            <span class="text-xs text-slate-500 ml-1">de ${m.total_tasks ?? 0}</span>
          </td>
          <td class="px-4 py-3">
            ${m.total_returns > 0
              ? `<span class="text-sm font-medium text-red-400">${m.total_returns}</span>`
              : `<span class="text-sm text-slate-500">—</span>`
            }
          </td>
          <td class="px-4 py-3">
            <div class="flex items-center gap-3">
              <div class="rate-bar flex-1">
                <div class="rate-fill" style="width:${rate}%; background:${barColor};"></div>
              </div>
              <span class="text-sm font-bold border rounded px-1.5 py-0.5 ${badgeClass} flex-shrink-0 min-w-[3rem] text-center">
                ${rate}%
              </span>
            </div>
          </td>
        </tr>`;
    }).join('');
  }

  function esc(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  loadRanking();
})();
