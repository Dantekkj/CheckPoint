// tasks.js — Lógica da página de tarefas do CheckPoint.
// Gerencia: cards, filtros, modal de nova tarefa e modal de check-in.

(function () {
  if (!Auth.guard()) return;
  Auth.renderHeader();

  const user = Auth.getUser();
  let allTasks = [];
  let currentFilter = '';

  // ─── Prioridade / Status helpers ─────────────────────────────────────────
  const PRIORITY_LABELS = { critical: 'Crítica', high: 'Alta', medium: 'Média', low: 'Baixa' };
  const PRIORITY_CLASSES = {
    critical: 'priority-critical',
    high:     'priority-high',
    medium:   'priority-medium',
    low:      'priority-low',
  };
  const STATUS_LABELS = {
    pending:       'Pendente',
    executor_done: 'Aguard. Validação',
    approved:      'Aprovada',
    returned:      'Devolvida',
  };
  const STATUS_CLASSES = {
    pending:       'status-pending',
    executor_done: 'status-executor_done',
    approved:      'status-approved',
    returned:      'status-returned',
  };

  // ─── Carregar e renderizar tarefas ────────────────────────────────────────
  async function loadTasks() {
    try {
      const url = currentFilter ? `/tasks?status=${currentFilter}` : '/tasks';
      allTasks = await API.get(url);
      renderCards(allTasks);
    } catch (err) {
      document.getElementById('tasks-grid').innerHTML =
        `<div class="card rounded-xl p-6 col-span-full text-center text-red-400 text-sm">Erro ao carregar tarefas: ${err.message}</div>`;
    }
  }

  function renderCards(tasks) {
    const grid = document.getElementById('tasks-grid');
    if (!tasks || tasks.length === 0) {
      grid.innerHTML = `<div class="card rounded-xl p-8 col-span-full text-center text-slate-500 text-sm">
        Nenhuma tarefa encontrada para este filtro.
      </div>`;
      return;
    }

    grid.innerHTML = tasks.map(t => buildCard(t)).join('');

    // Eventos dos cards
    grid.querySelectorAll('.btn-executor-checkin').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openCheckInModal(btn.dataset.id, 'executor');
      });
    });
    grid.querySelectorAll('.btn-validator-checkin').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openCheckInModal(btn.dataset.id, 'validator');
      });
    });
    grid.querySelectorAll('.card-clickable').forEach(card => {
      card.addEventListener('click', () => openDetail(card.dataset.id));
    });
  }

  // ─── Construir um card de tarefa ─────────────────────────────────────────
  function buildCard(t) {
    const isExecutor  = t.assignee_id  === user.id;
    const isValidator = t.validator_id === user.id;
    const isLeader    = user.role === 'leader';

    const isOverdue = t.due_date && t.status !== 'approved' && new Date(t.due_date) < new Date();

    // Linha do tempo dos dois check-ins
    const execDone = !!t.executor_checkin_at;
    const valDone  = !!t.validator_checkin_at && t.validator_decision === 'approved';
    const returned = t.validator_decision === 'returned';

    const dot1Class = execDone ? (returned ? 'dot-returned' : 'dot-done') : (t.status === 'pending' ? 'dot-waiting' : 'dot-pending');
    const dot2Class = valDone  ? 'dot-done' : (returned ? 'dot-returned' : 'dot-pending');
    const lineClass = execDone && !returned ? 'done' : '';

    const dot1Icon = execDone
      ? `<svg class="w-3 h-3 m-auto" fill="none" stroke="${returned?'#f87171':'#34d399'}" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`
      : `<svg class="w-3 h-3 m-auto" fill="none" stroke="#818cf8" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3"/><circle cx="12" cy="12" r="9" stroke-width="1.5"/></svg>`;

    const dot2Icon = valDone
      ? `<svg class="w-3 h-3 m-auto" fill="none" stroke="#34d399" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`
      : returned
        ? `<svg class="w-3 h-3 m-auto" fill="none" stroke="#f87171" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>`
        : `<svg class="w-3 h-3 m-auto" fill="none" stroke="#475569" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4"/></svg>`;

    // Botão de ação contextual
    let actionBtn = '';
    if (t.status === 'pending' && (isExecutor || isLeader)) {
      actionBtn = `<button class="btn-executor-checkin w-full mt-3 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition" data-id="${t.id}">
        📤 Fazer Check-In (Executor)
      </button>`;
    } else if (t.status === 'returned' && (isExecutor || isLeader)) {
      actionBtn = `<button class="btn-executor-checkin w-full mt-3 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white rounded-lg transition" data-id="${t.id}">
        🔄 Re-submeter Check-In
      </button>`;
    } else if (t.status === 'executor_done' && (isValidator || isLeader)) {
      actionBtn = `<button class="btn-validator-checkin w-full mt-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition" data-id="${t.id}">
        ✅ Validar Entrega
      </button>`;
    }

    // Borda lateral por status
    const borderAccent = {
      pending:       'border-l-4 border-slate-700',
      executor_done: 'border-l-4 border-indigo-500',
      approved:      'border-l-4 border-green-500',
      returned:      'border-l-4 border-red-500',
    }[t.status] || '';

    return `
      <div class="card rounded-xl p-4 ${borderAccent} cursor-pointer hover:border-slate-600 transition card-clickable" data-id="${t.id}">
        <!-- Header do card -->
        <div class="flex items-start justify-between gap-2 mb-3">
          <div class="flex-1 min-w-0">
            <h3 class="text-sm font-semibold text-white leading-snug truncate" title="${esc(t.title)}">${esc(t.title)}</h3>
            ${isOverdue ? '<p class="text-xs text-red-400 mt-0.5">⚠ Atrasada</p>' : (t.due_date ? `<p class="text-xs text-slate-500 mt-0.5">Prazo: ${formatDate(t.due_date)}</p>` : '')}
          </div>
          <div class="flex flex-col items-end gap-1 flex-shrink-0">
            <span class="badge ${PRIORITY_CLASSES[t.priority] || ''}">${PRIORITY_LABELS[t.priority] || t.priority}</span>
          </div>
        </div>

        <!-- Linha do tempo dos check-ins -->
        <div class="flex items-center gap-1 mb-3">
          <div class="checkin-step flex-1">
            <div class="checkin-dot ${dot1Class} flex items-center justify-center">${dot1Icon}</div>
            <div class="flex-1 ml-1">
              <p class="text-xs text-slate-500 leading-tight">1º Check-In</p>
              <p class="text-xs font-medium ${execDone ? (returned ? 'text-red-400' : 'text-green-400') : 'text-slate-500'}">
                ${execDone ? (returned ? 'Devolvido' : 'Concluído') : 'Executor'}
              </p>
            </div>
          </div>
          <div class="checkin-line ${lineClass} mx-2"></div>
          <div class="checkin-step flex-1">
            <div class="checkin-dot ${dot2Class} flex items-center justify-center">${dot2Icon}</div>
            <div class="flex-1 ml-1">
              <p class="text-xs text-slate-500 leading-tight">2º Check-In</p>
              <p class="text-xs font-medium ${valDone ? 'text-green-400' : returned ? 'text-red-400' : 'text-slate-500'}">
                ${valDone ? 'Aprovado' : returned ? 'Devolvido' : 'Validador'}
              </p>
            </div>
          </div>
        </div>

        <!-- Pessoas -->
        <div class="flex items-center justify-between mt-2">
          <div class="flex items-center gap-2">
            <div class="flex -space-x-1.5">
              <div class="w-6 h-6 bg-slate-700 rounded-full border border-slate-600 flex items-center justify-center text-xs font-bold text-slate-300" title="Executor: ${esc(t.assignee_name)}">
                ${t.assignee_avatar || (t.assignee_name?.[0] || '?')}
              </div>
              <div class="w-6 h-6 bg-indigo-900 rounded-full border border-indigo-700 flex items-center justify-center text-xs font-bold text-indigo-300" title="Validador: ${esc(t.validator_name)}">
                ${t.validator_avatar || (t.validator_name?.[0] || '?')}
              </div>
            </div>
            <span class="text-xs text-slate-500">${esc(t.assignee_name || '—')}</span>
          </div>
          <span class="text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_CLASSES[t.status] || ''}">
            ${STATUS_LABELS[t.status] || t.status}
          </span>
        </div>

        ${t.return_count > 0 ? `<p class="text-xs text-red-400/70 mt-2">↩ ${t.return_count} devolução${t.return_count > 1 ? 'ões' : ''}</p>` : ''}

        ${actionBtn}
      </div>`;
  }

  // ─── Filtros por aba ──────────────────────────────────────────────────────
  document.querySelectorAll('.filter-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-tab').forEach(b => {
        b.classList.remove('bg-indigo-600', 'text-white', 'active-tab');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('bg-indigo-600', 'text-white');
      btn.classList.remove('text-slate-400');
      currentFilter = btn.dataset.filter;
      loadTasks();
    });
  });

  // ─── Modal Nova Tarefa (líder) ────────────────────────────────────────────
  let users = [];

  async function loadUsers() {
    try {
      users = await API.get('/users');
      const aSelect = document.getElementById('task-assignee');
      const vSelect = document.getElementById('task-validator');
      [aSelect, vSelect].forEach(sel => {
        sel.innerHTML = '<option value="">— selecione —</option>' +
          users.map(u => `<option value="${u.id}">${esc(u.name)} (${esc(u.position || u.role)})</option>`).join('');
      });
    } catch { /* silencioso */ }
  }

  const btnNewTask   = document.getElementById('btn-new-task');
  const taskModal    = document.getElementById('task-modal');
  const taskForm     = document.getElementById('task-form');
  const modalCancel  = document.getElementById('modal-cancel');
  const modalError   = document.getElementById('modal-error');

  if (btnNewTask) {
    btnNewTask.addEventListener('click', () => {
      taskModal.classList.remove('hidden');
      loadUsers();
    });
  }
  if (modalCancel) modalCancel.addEventListener('click', () => taskModal.classList.add('hidden'));
  taskModal?.addEventListener('click', (e) => { if (e.target === taskModal) taskModal.classList.add('hidden'); });

  if (taskForm) {
    taskForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      modalError.classList.add('hidden');

      const body = {
        title:       document.getElementById('task-title').value.trim(),
        description: document.getElementById('task-desc').value.trim() || undefined,
        assignee_id: document.getElementById('task-assignee').value,
        validator_id:document.getElementById('task-validator').value,
        priority:    document.getElementById('task-priority').value,
        due_date:    document.getElementById('task-due').value || undefined,
      };

      try {
        await API.post('/tasks', body);
        taskModal.classList.add('hidden');
        taskForm.reset();
        loadTasks();
      } catch (err) {
        modalError.textContent = err.message;
        modalError.classList.remove('hidden');
      }
    });
  }

  // ─── Modal Check-In ──────────────────────────────────────────────────────
  const checkinModal   = document.getElementById('checkin-modal');
  const checkinForm    = document.getElementById('checkin-form');
  const checkinCancel  = document.getElementById('checkin-cancel');
  const checkinError   = document.getElementById('checkin-error');
  const decisionGroup  = document.getElementById('checkin-decision-group');

  function openCheckInModal(taskId, type) {
    const task = allTasks.find(t => t.id === taskId);
    if (!task) return;

    document.getElementById('checkin-task-id').value  = taskId;
    document.getElementById('checkin-type').value     = type;
    document.getElementById('checkin-task-name').textContent = task.title;
    document.getElementById('checkin-note').value     = '';
    checkinError.classList.add('hidden');

    // Configura para executor vs validador
    if (type === 'executor') {
      document.getElementById('checkin-title').textContent    = '1º Check-In — Conclusão';
      document.getElementById('checkin-subtitle').textContent = 'Você está marcando que concluiu esta tarefa.';
      document.getElementById('checkin-note-label').textContent = 'O que foi feito? *';
      document.getElementById('checkin-btn-text').textContent  = 'Confirmar Conclusão';
      decisionGroup.classList.add('hidden');
    } else {
      document.getElementById('checkin-title').textContent    = '2º Check-In — Validação';
      document.getElementById('checkin-subtitle').textContent = 'Você é o validador desta tarefa.';
      document.getElementById('checkin-note-label').textContent = 'Seu feedback *';
      document.getElementById('checkin-btn-text').textContent  = 'Enviar Decisão';
      decisionGroup.classList.remove('hidden');
      // Limpa seleção anterior
      document.querySelectorAll('input[name="decision"]').forEach(r => r.checked = false);
    }

    checkinModal.classList.remove('hidden');
    setTimeout(() => document.getElementById('checkin-note').focus(), 100);
  }

  if (checkinCancel) checkinCancel.addEventListener('click', () => checkinModal.classList.add('hidden'));
  checkinModal?.addEventListener('click', (e) => { if (e.target === checkinModal) checkinModal.classList.add('hidden'); });

  if (checkinForm) {
    checkinForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      checkinError.classList.add('hidden');

      const taskId  = document.getElementById('checkin-task-id').value;
      const type    = document.getElementById('checkin-type').value;
      const note    = document.getElementById('checkin-note').value.trim();
      const spinner = document.getElementById('checkin-spinner');
      const btnText = document.getElementById('checkin-btn-text');

      if (!note) {
        checkinError.textContent = 'A nota é obrigatória.';
        checkinError.classList.remove('hidden');
        return;
      }

      let body = { note };

      if (type === 'validator') {
        const decision = document.querySelector('input[name="decision"]:checked')?.value;
        if (!decision) {
          checkinError.textContent = 'Selecione uma decisão: Aprovar ou Devolver.';
          checkinError.classList.remove('hidden');
          return;
        }
        body.decision = decision;
      }

      spinner.classList.remove('hidden');
      btnText.textContent = 'Enviando...';
      const submitBtn = document.getElementById('checkin-submit');
      submitBtn.disabled = true;

      try {
        const endpoint = type === 'executor' ? 'executor-checkin' : 'validator-checkin';
        await API.post(`/tasks/${taskId}/${endpoint}`, body);
        checkinModal.classList.add('hidden');
        loadTasks();
      } catch (err) {
        checkinError.textContent = err.message;
        checkinError.classList.remove('hidden');
      } finally {
        spinner.classList.add('hidden');
        btnText.textContent = type === 'executor' ? 'Confirmar Conclusão' : 'Enviar Decisão';
        submitBtn.disabled = false;
      }
    });
  }

  // ─── Drawer de detalhes ───────────────────────────────────────────────────
  const drawer         = document.getElementById('detail-drawer');
  const drawerBody     = document.getElementById('detail-body');
  const drawerTitle    = document.getElementById('detail-title');
  const drawerClose    = document.getElementById('detail-close');
  const drawerBackdrop = document.getElementById('detail-backdrop');

  function closeDetail() {
    drawer.classList.add('hidden');
    drawerBackdrop.classList.add('hidden');
  }

  window.closeDetail = closeDetail;

  if (drawerClose)    drawerClose.addEventListener('click', closeDetail);

  async function openDetail(taskId) {
    try {
      const task = await API.get(`/tasks/${taskId}`);
      drawerTitle.textContent = task.title;

      const typeIcons = {
        comment:           '💬',
        checkin_exec:      '📤',
        checkin_val_ok:    '✅',
        checkin_val_return:'↩️',
      };

      const commentsHtml = task.comments?.length
        ? task.comments.map(c => `
          <div class="flex gap-2.5 items-start">
            <div class="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-bold text-indigo-400 flex-shrink-0">
              ${c.author_avatar || c.author_name?.[0] || '?'}
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center gap-2">
                <span class="text-xs font-medium text-white">${esc(c.author_name)}</span>
                <span class="text-xs">${typeIcons[c.type] || '💬'}</span>
                <span class="text-xs text-slate-600">${formatDate(c.created_at)}</span>
              </div>
              <p class="text-xs text-slate-400 mt-1">${esc(c.content)}</p>
            </div>
          </div>`).join('')
        : '<p class="text-xs text-slate-500">Sem histórico de comentários.</p>';

      drawerBody.innerHTML = `
        <div>
          <p class="text-xs text-slate-500 mb-1">Descrição</p>
          <p class="text-sm text-slate-300">${esc(task.description) || '<span class="text-slate-600">—</span>'}</p>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <p class="text-xs text-slate-500 mb-1">Executor</p>
            <p class="text-sm text-white">${esc(task.assignee_name || '—')}</p>
          </div>
          <div>
            <p class="text-xs text-slate-500 mb-1">Validador</p>
            <p class="text-sm text-white">${esc(task.validator_name || '—')}</p>
          </div>
          <div>
            <p class="text-xs text-slate-500 mb-1">Status</p>
            <p class="text-sm">${STATUS_LABELS[task.status] || task.status}</p>
          </div>
          <div>
            <p class="text-xs text-slate-500 mb-1">Devoluções</p>
            <p class="text-sm ${task.return_count > 0 ? 'text-red-400' : 'text-slate-400'}">${task.return_count}</p>
          </div>
        </div>
        ${task.executor_checkin_note ? `
          <div class="bg-indigo-900/30 border border-indigo-800/50 rounded-lg p-3">
            <p class="text-xs font-medium text-indigo-400 mb-1">📤 Nota do Executor</p>
            <p class="text-xs text-slate-300">${esc(task.executor_checkin_note)}</p>
          </div>` : ''}
        ${task.validator_checkin_note ? `
          <div class="bg-${task.validator_decision === 'approved' ? 'green' : 'red'}-900/30 border border-${task.validator_decision === 'approved' ? 'green' : 'red'}-800/50 rounded-lg p-3">
            <p class="text-xs font-medium text-${task.validator_decision === 'approved' ? 'green' : 'red'}-400 mb-1">${task.validator_decision === 'approved' ? '✅' : '↩️'} Nota do Validador</p>
            <p class="text-xs text-slate-300">${esc(task.validator_checkin_note)}</p>
          </div>` : ''}
        <div>
          <p class="text-xs font-semibold text-slate-400 mb-3 uppercase tracking-wider">Histórico</p>
          <div class="space-y-3">${commentsHtml}</div>
        </div>`;

      drawer.classList.remove('hidden');
      drawerBackdrop.classList.remove('hidden');
    } catch (err) {
      console.error('Erro ao abrir detalhes:', err);
    }
  }

  // ─── Utilitários ─────────────────────────────────────────────────────────
  function esc(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function formatDate(iso) {
    if (!iso) return '—';
    try { return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
    catch { return iso; }
  }

  // ─── Init ─────────────────────────────────────────────────────────────────
  loadTasks();

  // Ativa a primeira aba (Todas)
  const firstTab = document.querySelector('.filter-tab[data-filter=""]');
  if (firstTab) firstTab.classList.add('bg-indigo-600', 'text-white');
})();
