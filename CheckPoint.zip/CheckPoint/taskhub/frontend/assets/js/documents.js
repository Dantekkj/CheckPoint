// documents.js — Lógica da página de Documentos do CheckPoint
// Gerencia envio, visualização, assinatura e download de documentos.

// API_BASE já é declarado no api.js

// Estado local
let allDocs    = [];
let currentTab = 'all';
let sigCanvas, sigCtx, isDrawing = false;
let currentUser = null;

// ─── Inicialização ────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  if (!Auth.guard()) return;
  Auth.renderHeader();
  currentUser = Auth.getUser();

  await loadUsers();
  await loadDocuments();
  setupCanvas();
  setupDropZone();
  setupTabs();
  setupModal();
  setupWebSocket();
  loadUnreadBadge();
});

// ─── Carrega usuários para o select de destinatário ───────────────────────────

async function loadUsers() {
  try {
    const users = await API.get('/users');
    const select = document.getElementById('doc-recipient');
    select.innerHTML = '';
    users
      .filter(u => u.id !== currentUser.id)
      .forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = `${u.avatar || u.name[0]} ${u.name} (${u.role === 'leader' ? 'Líder' : u.position || 'Membro'})`;
        select.appendChild(opt);
      });
  } catch (err) {
    console.error('Erro ao carregar usuários:', err);
  }
}

// ─── Carrega documentos da API ────────────────────────────────────────────────

async function loadDocuments() {
  try {
    allDocs = await API.get('/documents');
    renderDocs();
  } catch (err) {
    document.getElementById('docs-grid').innerHTML =
      `<div class="card rounded-xl p-6 col-span-full text-center text-red-400 text-sm">Erro ao carregar documentos.</div>`;
  }
}

// ─── Renderiza os cards de documentos ────────────────────────────────────────

function renderDocs() {
  const grid = document.getElementById('docs-grid');
  const userId = currentUser.id;

  let filtered = allDocs;
  if (currentTab === 'inbox')   filtered = allDocs.filter(d => d.recipient_id === userId);
  if (currentTab === 'sent')    filtered = allDocs.filter(d => d.sender_id === userId);
  if (currentTab === 'pending') filtered = allDocs.filter(d => d.status === 'pending_signature');
  if (currentTab === 'signed')  filtered = allDocs.filter(d => d.status === 'signed');

  if (!filtered.length) {
    grid.innerHTML = `<div class="card rounded-xl p-10 col-span-full text-center text-slate-500 text-sm">
      <svg class="w-10 h-10 mx-auto mb-3 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
      </svg>
      Nenhum documento encontrado.
    </div>`;
    return;
  }

  grid.innerHTML = filtered.map(doc => renderDocCard(doc)).join('');

  // Eventos dos cards
  grid.querySelectorAll('.doc-card').forEach(card => {
    card.addEventListener('click', () => openDrawer(card.dataset.docId));
  });
}

function renderDocCard(doc) {
  const userId   = currentUser.id;
  const isSender = doc.sender_id === userId;
  const statusLabel = { pending_signature: 'Aguard. Assinatura', signed: 'Assinado', rejected: 'Rejeitado' };
  const statusClass  = { pending_signature: 'doc-pending', signed: 'doc-signed', rejected: 'doc-rejected' };
  const typeLabels  = { general: '📄 Geral', task_change: '✏️ Alteração', new_task: '➕ Nova Tarefa' };

  const senderSigned    = doc.sender_signed_at    ? '✅' : '⏳';
  const recipientSigned = doc.recipient_signed_at ? '✅' : '⏳';

  const ext = getFileExt(doc.file_name);
  const iconClass = getFileIconClass(ext);

  const dateStr = new Date(doc.created_at).toLocaleDateString('pt-BR', { day:'2-digit', month:'short', year:'numeric' });

  return `
    <div class="card rounded-xl p-4 cursor-pointer hover:border-slate-600 transition doc-card" data-doc-id="${doc.id}">
      <div class="flex items-start gap-3 mb-3">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold flex-shrink-0 ${iconClass}">
          ${ext.toUpperCase()}
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-semibold text-white truncate">${escHtml(doc.title)}</p>
          <p class="text-xs text-slate-500 mt-0.5">${typeLabels[doc.doc_type] || '📄 Geral'} · ${dateStr}</p>
        </div>
        <span class="badge text-[10px] px-2 py-0.5 rounded-full font-bold border ${statusClass[doc.status]}">
          ${statusLabel[doc.status]}
        </span>
      </div>

      ${doc.message ? `<p class="text-xs text-slate-400 mb-3 line-clamp-2 bg-slate-800/50 rounded-lg px-3 py-2">${escHtml(doc.message)}</p>` : ''}

      <!-- Assinantes -->
      <div class="flex items-center gap-2 text-xs">
        <div class="flex items-center gap-1.5 flex-1">
          <div class="w-5 h-5 bg-indigo-700 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
            ${(doc.sender_avatar || doc.sender_name?.[0] || '?')}
          </div>
          <span class="text-slate-400 truncate">${escHtml(doc.sender_name || '—')}</span>
          <span class="text-base">${senderSigned}</span>
        </div>
        <svg class="w-3 h-3 text-slate-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
        <div class="flex items-center gap-1.5 flex-1 justify-end">
          <span class="text-base">${recipientSigned}</span>
          <span class="text-slate-400 truncate">${escHtml(doc.recipient_name || '—')}</span>
          <div class="w-5 h-5 bg-emerald-700 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0">
            ${(doc.recipient_avatar || doc.recipient_name?.[0] || '?')}
          </div>
        </div>
      </div>
    </div>
  `;
}

// ─── Drawer de detalhes ───────────────────────────────────────────────────────

async function openDrawer(docId) {
  const doc = allDocs.find(d => d.id === docId);
  if (!doc) return;

  const drawer = document.getElementById('doc-drawer');
  const body   = document.getElementById('drawer-body');
  document.getElementById('drawer-title').textContent = doc.title;
  document.getElementById('drawer-backdrop').classList.remove('hidden');

  const userId   = currentUser.id;
  const isSender = doc.sender_id === userId;
  const isRecipient = doc.recipient_id === userId;

  const mySignedAt    = isSender ? doc.sender_signed_at : doc.recipient_signed_at;
  const canSign = !mySignedAt && doc.status !== 'rejected' && (isSender || isRecipient);
  const canReject = isRecipient && doc.status === 'pending_signature';

  const typeLabels = { general: '📄 Geral', task_change: '✏️ Solicitação de Alteração', new_task: '➕ Nova Tarefa' };
  const ext = getFileExt(doc.file_name);

  body.innerHTML = `
    <!-- Arquivo -->
    <div class="card rounded-xl p-4">
      <div class="flex items-center gap-3">
        <div class="w-12 h-12 rounded-xl flex items-center justify-center text-sm font-bold ${getFileIconClass(ext)}">
          ${ext.toUpperCase()}
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-semibold text-white truncate">${escHtml(doc.file_name)}</p>
          <p class="text-xs text-slate-500">${formatSize(doc.file_size)}</p>
        </div>
        <a href="${API_BASE}/documents/${doc.id}/download?token=${encodeURIComponent(Auth.getToken())}"
           class="flex-shrink-0 bg-indigo-700/50 hover:bg-indigo-700 text-indigo-300 text-xs px-3 py-1.5 rounded-lg transition flex items-center gap-1.5"
           download>
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
          </svg>
          Baixar
        </a>
      </div>
    </div>

    <!-- Info -->
    <div class="space-y-2 text-xs">
      <div class="flex justify-between">
        <span class="text-slate-500">Tipo</span>
        <span class="text-slate-300">${typeLabels[doc.doc_type] || '—'}</span>
      </div>
      <div class="flex justify-between">
        <span class="text-slate-500">Enviado em</span>
        <span class="text-slate-300">${new Date(doc.created_at).toLocaleString('pt-BR')}</span>
      </div>
      <div class="flex justify-between">
        <span class="text-slate-500">Status</span>
        <span class="font-semibold ${doc.status === 'signed' ? 'text-green-400' : doc.status === 'rejected' ? 'text-red-400' : 'text-blue-400'}">
          ${doc.status === 'signed' ? '✅ Assinado' : doc.status === 'rejected' ? '❌ Rejeitado' : '⏳ Aguardando'}
        </span>
      </div>
    </div>

    ${doc.message ? `
    <div>
      <p class="text-xs text-slate-500 mb-1">Mensagem</p>
      <p class="text-sm text-slate-300 bg-slate-800/50 rounded-lg px-3 py-2">${escHtml(doc.message)}</p>
    </div>` : ''}

    <!-- Assinantes -->
    <div>
      <p class="text-xs text-slate-500 mb-2">Assinaturas</p>
      <div class="space-y-2">
        ${renderSignerRow('Remetente', doc.sender_name, doc.sender_avatar, doc.sender_signed_at, doc.sender_signature)}
        ${renderSignerRow('Destinatário', doc.recipient_name, doc.recipient_avatar, doc.recipient_signed_at, doc.recipient_signature)}
      </div>
    </div>

    <!-- Ações -->
    ${canSign ? `
    <div class="space-y-3">
      <div>
        <div class="flex items-center justify-between mb-2">
          <p class="text-xs text-slate-400 font-medium">Assinar Documento</p>
          <button type="button" id="clear-drawer-sig" class="text-xs text-slate-600 hover:text-red-400 transition">Limpar</button>
        </div>
        <canvas id="drawer-sig-canvas" class="sig-canvas w-full" height="80"></canvas>
        <p class="text-xs text-slate-600 mt-1">Desenhe sua assinatura acima</p>
      </div>
      <button id="btn-sign" data-doc-id="${doc.id}"
        class="w-full bg-green-700 hover:bg-green-600 text-white text-sm font-medium py-2 rounded-lg transition flex items-center justify-center gap-2">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        Assinar e Confirmar
      </button>
    </div>` : ''}

    ${canReject ? `
    <button id="btn-reject" data-doc-id="${doc.id}"
      class="w-full bg-red-900/50 hover:bg-red-900 border border-red-800 text-red-400 text-sm font-medium py-2 rounded-lg transition">
      Rejeitar Documento
    </button>` : ''}
  `;

  drawer.classList.remove('hidden');

  // Setup canvas de assinatura no drawer
  if (canSign) {
    const canvas = document.getElementById('drawer-sig-canvas');
    setupCanvasInstance(canvas);
    document.getElementById('clear-drawer-sig')?.addEventListener('click', () => {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    });
    document.getElementById('btn-sign')?.addEventListener('click', () => signDoc(doc.id, canvas));
  }
  document.getElementById('btn-reject')?.addEventListener('click', () => rejectDoc(doc.id));


  // O link de download já contém o token na query string — funciona nativamente

}

function renderSignerRow(label, name, avatar, signedAt, signature) {
  const signed = !!signedAt;
  return `
    <div class="flex items-center gap-3 ${signed ? 'sig-badge-done' : 'sig-badge-pend'} rounded-lg px-3 py-2">
      <div class="w-7 h-7 ${signed ? 'bg-green-800' : 'bg-slate-700'} rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
        ${avatar || name?.[0] || '?'}
      </div>
      <div class="flex-1 min-w-0">
        <p class="text-xs font-medium text-white">${escHtml(name || '—')}</p>
        <p class="text-[10px] text-slate-500">${label}</p>
      </div>
      <div class="text-right">
        ${signed
          ? `<p class="text-[10px] text-green-400 font-semibold">✅ Assinado</p>
             <p class="text-[10px] text-slate-600">${new Date(signedAt).toLocaleDateString('pt-BR')}</p>`
          : `<p class="text-[10px] text-slate-500">⏳ Pendente</p>`
        }
      </div>
    </div>
  `;
}

function closeDrawer() {
  document.getElementById('doc-drawer').classList.add('hidden');
  document.getElementById('drawer-backdrop').classList.add('hidden');
}
document.getElementById('drawer-close').addEventListener('click', closeDrawer);

// ─── Assinar documento ────────────────────────────────────────────────────────

async function signDoc(docId, canvas) {
  try {
    const signature = canvas ? canvas.toDataURL() : '';
    await API.patch(`/documents/${docId}/sign`, { signature });
    closeDrawer();
    await loadDocuments();
  } catch (err) {
    alert('Erro ao assinar: ' + err.message);
  }
}

async function rejectDoc(docId) {
  if (!confirm('Tem certeza que deseja rejeitar este documento?')) return;
  try {
    await API.patch(`/documents/${docId}/reject`, {});
    closeDrawer();
    await loadDocuments();
  } catch (err) {
    alert('Erro ao rejeitar: ' + err.message);
  }
}

// ─── Canvas de assinatura (modal de envio) ────────────────────────────────────

function setupCanvas() {
  sigCanvas = document.getElementById('sig-canvas');
  sigCanvas.width = sigCanvas.offsetWidth || 500;
  setupCanvasInstance(sigCanvas);

  document.getElementById('clear-sig').addEventListener('click', () => {
    sigCtx = sigCanvas.getContext('2d');
    sigCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
  });
}

function setupCanvasInstance(canvas) {
  canvas.width = canvas.offsetWidth || 400;
  const ctx = canvas.getContext('2d');
  ctx.strokeStyle = '#818cf8';
  ctx.lineWidth   = 2;
  ctx.lineCap     = 'round';
  ctx.lineJoin    = 'round';

  let drawing = false, lastX = 0, lastY = 0;

  const getPos = (e) => {
    const rect = canvas.getBoundingClientRect();
    const src = e.touches ? e.touches[0] : e;
    return { x: src.clientX - rect.left, y: src.clientY - rect.top };
  };

  const start = (e) => { drawing = true; const p = getPos(e); lastX = p.x; lastY = p.y; };
  const stop  = () => { drawing = false; ctx.beginPath(); };
  const draw  = (e) => {
    if (!drawing) return;
    e.preventDefault();
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    lastX = p.x; lastY = p.y;
  };

  canvas.addEventListener('mousedown', start);
  canvas.addEventListener('mouseup', stop);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('touchstart', start, { passive: false });
  canvas.addEventListener('touchend', stop);
  canvas.addEventListener('touchmove', draw, { passive: false });
}

// ─── Drop Zone de arquivo ─────────────────────────────────────────────────────

function setupDropZone() {
  const zone  = document.getElementById('drop-zone');
  const input = document.getElementById('doc-file');

  zone.addEventListener('click', () => input.click());

  zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('drag-over'); });
  zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });

  input.addEventListener('change', () => {
    if (input.files.length) handleFile(input.files[0]);
  });

  document.getElementById('btn-remove-file').addEventListener('click', (e) => {
    e.stopPropagation();
    input.value = '';
    document.getElementById('drop-placeholder').classList.remove('hidden');
    document.getElementById('drop-preview').classList.add('hidden');
  });
}

function handleFile(file) {
  const maxSize = 20 * 1024 * 1024;
  if (file.size > maxSize) { alert('Arquivo muito grande. Limite: 20 MB.'); return; }

  const ext = getFileExt(file.name);
  document.getElementById('file-icon-preview').textContent = ext.toUpperCase();
  document.getElementById('file-icon-preview').className = `w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold ${getFileIconClass(ext)}`;
  document.getElementById('file-name-preview').textContent = file.name;
  document.getElementById('file-size-preview').textContent = formatSize(file.size);
  document.getElementById('drop-placeholder').classList.add('hidden');
  document.getElementById('drop-preview').classList.remove('hidden');

  // Atualiza o input file se veio do drag
  const dt = new DataTransfer();
  dt.items.add(file);
  document.getElementById('doc-file').files = dt.files;
}

// ─── Tabs de filtro ───────────────────────────────────────────────────────────

function setupTabs() {
  document.querySelectorAll('.doc-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      currentTab = btn.dataset.tab;
      document.querySelectorAll('.doc-tab').forEach(b => {
        b.classList.remove('tab-active');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('tab-active');
      btn.classList.remove('text-slate-400');
      renderDocs();
    });
  });
}

// ─── Modal de envio ───────────────────────────────────────────────────────────

function setupModal() {
  const modal = document.getElementById('doc-modal');

  document.getElementById('btn-new-doc').addEventListener('click', () => {
    modal.classList.remove('hidden');
    setTimeout(setupCanvas, 50);
  });
  document.getElementById('doc-modal-close').addEventListener('click', closeModal);
  document.getElementById('doc-cancel').addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

  document.getElementById('doc-form').addEventListener('submit', submitDoc);
}

function closeModal() {
  document.getElementById('doc-modal').classList.add('hidden');
  document.getElementById('doc-form').reset();
  document.getElementById('drop-placeholder').classList.remove('hidden');
  document.getElementById('drop-preview').classList.add('hidden');
  document.getElementById('doc-error').classList.add('hidden');
  if (sigCtx) sigCtx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
}

async function submitDoc(e) {
  e.preventDefault();
  const errEl = document.getElementById('doc-error');
  const btn   = document.getElementById('doc-submit');
  errEl.classList.add('hidden');

  const file = document.getElementById('doc-file').files[0];
  if (!file) { showError(errEl, 'Selecione um arquivo para enviar.'); return; }

  const title     = document.getElementById('doc-title').value.trim();
  const recipient = document.getElementById('doc-recipient').value;
  const docType   = document.getElementById('doc-type').value;
  const message   = document.getElementById('doc-message').value.trim();

  if (!title || !recipient) { showError(errEl, 'Preencha todos os campos obrigatórios.'); return; }

  // Captura assinatura do canvas se houver traço
  let senderSignature = '';
  if (sigCanvas) {
    const imgData = sigCanvas.getContext('2d').getImageData(0, 0, sigCanvas.width, sigCanvas.height);
    const hasTrack = imgData.data.some((v, i) => i % 4 === 3 && v > 0);
    if (hasTrack) senderSignature = sigCanvas.toDataURL();
  }

  btn.disabled = true;
  btn.innerHTML = `<svg class="animate-spin w-4 h-4 text-white" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg> Enviando...`;

  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title);
    formData.append('recipient_id', recipient);
    formData.append('doc_type', docType);
    formData.append('message', message);
    if (senderSignature) formData.append('sender_signature', senderSignature);

    const token = Auth.getToken();
    const resp = await fetch(`${API_BASE}/documents`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData
    });
    if (resp.status === 401) { Auth.logout(); return; }
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Erro ao enviar');

    closeModal();
    await loadDocuments();
  } catch (err) {
    showError(errEl, err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg> Enviar Documento`;
  }
}

// ─── WebSocket ────────────────────────────────────────────────────────────────

function setupWebSocket() {
  const token = Auth.getToken();
  const ws = new WebSocket(`ws://localhost:3000/ws`);
  ws.onmessage = async (e) => {
    const msg = JSON.parse(e.data);
    if (['document_sent','document_signed','document_rejected'].includes(msg.type)) {
      await loadDocuments();
    }
  };
}

// ─── Badge de mensagens não lidas (nav) ───────────────────────────────────────

async function loadUnreadBadge() {
  try {
    const { count } = await API.get('/extensions/unread');
    const badge = document.getElementById('nav-unread-badge');
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove('hidden');
    }
  } catch { /* ignora */ }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getFileExt(name) {
  return (name || '').split('.').pop().toLowerCase() || 'file';
}

function getFileIconClass(ext) {
  if (['pdf'].includes(ext))               return 'file-icon-pdf';
  if (['doc','docx'].includes(ext))        return 'file-icon-doc';
  if (['xls','xlsx'].includes(ext))        return 'file-icon-xls';
  if (['ppt','pptx'].includes(ext))        return 'file-icon-ppt';
  if (['png','jpg','jpeg'].includes(ext))  return 'file-icon-img';
  return 'file-icon-txt';
}

function formatSize(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function escHtml(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showError(el, msg) {
  el.textContent = msg;
  el.classList.remove('hidden');
}
