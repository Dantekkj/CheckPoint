// messages.js — Sistema de Ramais / Mensagens Internas do CheckPoint
// Gerencia conversas por ramal com atualização em tempo real via WebSocket.

// API_BASE já é declarado no api.js

// Estado local
let currentUser     = null;
let myExtension     = null;
let allExtensions   = [];
let conversations   = [];
let activePartnerId = null;
let messages        = [];
let ws              = null;
let contactsTab     = 'conversations'; // 'conversations' | 'all'
let searchTerm      = '';
let pollInterval    = null;

// ─── Inicialização ────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', async () => {
  if (!Auth.guard()) return;
  Auth.renderHeader();
  currentUser = Auth.getUser();

  // Atribuir ramal ao usuário se ainda não tiver
  myExtension = await assignExtension();
  if (myExtension) {
    document.getElementById('my-extension').textContent = myExtension.extension_number;
  }

  await Promise.all([loadExtensions(), loadConversations()]);
  setupSearch();
  setupContactsTabs();
  setupMessageInput();
  setupWebSocket();
});

// ─── Atribuição de ramal ──────────────────────────────────────────────────────

async function assignExtension() {
  try {
    const ext = await API.post('/extensions/assign', {});
    return ext;
  } catch (err) {
    console.error('Erro ao atribuir ramal:', err);
    return null;
  }
}

// ─── Carrega todos os ramais ──────────────────────────────────────────────────

async function loadExtensions() {
  try {
    allExtensions = await API.get('/extensions');
  } catch (err) {
    console.error('Erro ao carregar ramais:', err);
  }
}

// ─── Carrega conversas ────────────────────────────────────────────────────────

async function loadConversations() {
  try {
    conversations = await API.get('/extensions/messages');
    renderContactList();
    updateUnreadBadge();
  } catch (err) {
    console.error('Erro ao carregar conversas:', err);
  }
}

// ─── Renderiza lista de contatos / conversas ──────────────────────────────────

function renderContactList() {
  const list = document.getElementById('conv-list');
  const search = searchTerm.toLowerCase();

  if (contactsTab === 'conversations') {
    let filtered = conversations;
    if (search) {
      filtered = conversations.filter(c =>
        c.partner?.name?.toLowerCase().includes(search) ||
        c.partner?.extension_number?.includes(search)
      );
    }

    if (!filtered.length) {
      list.innerHTML = `<div class="px-4 py-8 text-xs text-slate-500 text-center">
        ${search ? 'Nenhuma conversa encontrada.' : 'Nenhuma conversa ainda.<br>Inicie uma pela aba "Todos os Ramais".'}
      </div>`;
      return;
    }

    list.innerHTML = filtered.map(c => renderConvItem(c)).join('');
  } else {
    // Todos os ramais
    let filtered = allExtensions.filter(e => e.user_id !== currentUser.id);
    if (search) {
      filtered = filtered.filter(e =>
        e.name?.toLowerCase().includes(search) ||
        e.extension_number?.includes(search)
      );
    }

    if (!filtered.length) {
      list.innerHTML = `<div class="px-4 py-8 text-xs text-slate-500 text-center">Nenhum ramal encontrado.</div>`;
      return;
    }

    list.innerHTML = filtered.map(e => renderExtItem(e)).join('');
  }

  // Eventos de clique
  list.querySelectorAll('[data-partner-id]').forEach(el => {
    el.addEventListener('click', () => openChat(el.dataset.partnerId));
    if (el.dataset.partnerId === activePartnerId) el.classList.add('active');
  });
}

function renderConvItem(conv) {
  const p = conv.partner || {};
  const unread = conv.unread_count > 0;
  const lastMsg = conv.last_message;
  const lastContent = lastMsg ? (lastMsg.from_user_id === currentUser.id ? '↗ ' : '') + lastMsg.content : '—';
  const timeStr = conv.last_at ? formatRelativeTime(conv.last_at) : '';

  return `
    <div class="conv-item px-4 py-3 flex items-center gap-3 ${conv.partner_id === activePartnerId ? 'active' : ''}" data-partner-id="${p.id}">
      <div class="w-9 h-9 bg-indigo-700 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
        ${p.avatar || p.name?.[0] || '?'}
      </div>
      <div class="flex-1 min-w-0">
        <div class="flex items-center justify-between">
          <p class="text-sm font-medium text-white truncate">${escHtml(p.name || '—')}</p>
          <span class="text-[10px] text-slate-600 flex-shrink-0 ml-2">${timeStr}</span>
        </div>
        <div class="flex items-center justify-between">
          <p class="text-xs text-slate-500 truncate">${escHtml(lastContent)}</p>
          ${unread ? `<span class="unread-badge flex-shrink-0 ml-2">${conv.unread_count}</span>` : ''}
        </div>
      </div>
    </div>
  `;
}

function renderExtItem(ext) {
  const roleLabel = ext.role === 'leader' ? 'Líder' : ext.position || 'Membro';
  return `
    <div class="conv-item px-4 py-3 flex items-center gap-3 ${ext.user_id === activePartnerId ? 'active' : ''}" data-partner-id="${ext.user_id}">
      <div class="w-9 h-9 bg-slate-700 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0">
        ${ext.avatar || ext.name?.[0] || '?'}
      </div>
      <div class="flex-1 min-w-0">
        <p class="text-sm font-medium text-white truncate">${escHtml(ext.name)}</p>
        <p class="text-xs text-slate-500">${roleLabel}</p>
      </div>
      <span class="ext-chip text-xs">${ext.extension_number}</span>
    </div>
  `;
}

// ─── Abre chat com um parceiro ─────────────────────────────────────────────────

async function openChat(partnerId) {
  activePartnerId = partnerId;

  // Atualiza visual da lista
  document.querySelectorAll('[data-partner-id]').forEach(el => {
    el.classList.toggle('active', el.dataset.partnerId === partnerId);
  });

  // Encontra dados do parceiro
  const ext = allExtensions.find(e => e.user_id === partnerId);
  const conv = conversations.find(c => c.partner_id === partnerId);
  const partner = ext || conv?.partner || {};

  // Cabeçalho do chat
  document.getElementById('chat-avatar').textContent = partner.avatar || partner.name?.[0] || '?';
  document.getElementById('chat-name').textContent   = partner.name || '—';
  document.getElementById('chat-ext').textContent    = ext?.extension_number ? `Ramal ${ext.extension_number}` : (partner.role === 'leader' ? 'Tech Lead' : partner.position || 'Membro');

  document.getElementById('no-chat').classList.add('hidden');
  document.getElementById('active-chat').classList.remove('hidden');

  await loadMessages(partnerId);
  document.getElementById('msg-input').focus();

  // Atualiza contagem de não lidas
  await loadConversations();
}

// ─── Carrega mensagens da conversa ────────────────────────────────────────────

async function loadMessages(partnerId) {
  try {
    messages = await API.get(`/extensions/messages/${partnerId}`);
    renderMessages();
  } catch (err) {
    console.error('Erro ao carregar mensagens:', err);
  }
}

function renderMessages() {
  const list = document.getElementById('msg-list');

  if (!messages.length) {
    list.innerHTML = `<div class="text-center text-xs text-slate-600 py-8">Nenhuma mensagem. Diga olá! 👋</div>`;
    return;
  }

  // Agrupa por data
  let lastDate = '';
  list.innerHTML = messages.map(msg => {
    const isMe = msg.from_user_id === currentUser.id;
    const msgDate = new Date(msg.created_at).toLocaleDateString('pt-BR');
    let dateSep = '';
    if (msgDate !== lastDate) {
      lastDate = msgDate;
      dateSep = `<div class="flex items-center gap-3 my-4">
        <div class="flex-1 h-px bg-slate-800"></div>
        <span class="text-[10px] text-slate-600 font-medium">${msgDate}</span>
        <div class="flex-1 h-px bg-slate-800"></div>
      </div>`;
    }

    const timeStr = new Date(msg.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    return `${dateSep}<div class="flex ${isMe ? 'justify-end' : 'justify-start'} pop-in">
      <div class="max-w-[70%]">
        ${!isMe ? `<div class="flex items-center gap-1.5 mb-1 ml-1">
          <span class="text-xs font-medium text-indigo-400">${escHtml(msg.from_name)}</span>
          <span class="ext-chip text-[9px]">${msg.from_ext}</span>
        </div>` : ''}
        <div class="${isMe ? 'bubble-me' : 'bubble-them'} px-3.5 py-2 text-sm leading-relaxed">
          ${escHtml(msg.content)}
        </div>
        <p class="text-[10px] text-slate-600 mt-1 ${isMe ? 'text-right' : 'text-left'} px-1">${timeStr}</p>
      </div>
    </div>`;
  }).join('');

  // Scroll para o final
  list.scrollTop = list.scrollHeight;
}

// ─── Enviar mensagem ──────────────────────────────────────────────────────────

function setupMessageInput() {
  const input  = document.getElementById('msg-input');
  const sendBtn = document.getElementById('send-btn');

  sendBtn.addEventListener('click', sendMessage);

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Auto-resize do textarea
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
  });
}

async function sendMessage() {
  if (!activePartnerId) return;
  const input   = document.getElementById('msg-input');
  const content = input.value.trim();
  if (!content) return;

  input.value = '';
  input.style.height = 'auto';

  try {
    const msg = await API.post('/extensions/messages', {
      to_user_id: activePartnerId,
      content
    });
    messages.push(msg);
    renderMessages();

    // Atualiza conversas na lista
    const convIdx = conversations.findIndex(c => c.partner_id === activePartnerId);
    if (convIdx >= 0) {
      conversations[convIdx].last_at = msg.created_at;
      conversations[convIdx].last_message = msg;
    } else {
      await loadConversations();
    }
    renderContactList();
  } catch (err) {
    alert('Erro ao enviar: ' + err.message);
  }
}

// ─── Tabs de contatos ─────────────────────────────────────────────────────────

function setupContactsTabs() {
  document.querySelectorAll('.contacts-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      contactsTab = btn.dataset.contactsTab;
      document.querySelectorAll('.contacts-tab').forEach(b => {
        b.classList.remove('text-indigo-400', 'border-indigo-500');
        b.classList.add('text-slate-500', 'border-transparent');
      });
      btn.classList.add('text-indigo-400', 'border-indigo-500');
      btn.classList.remove('text-slate-500', 'border-transparent');
      renderContactList();
    });
  });
}

// ─── Busca de contatos ────────────────────────────────────────────────────────

function setupSearch() {
  document.getElementById('search-contacts').addEventListener('input', (e) => {
    searchTerm = e.target.value;
    renderContactList();
  });
}

// ─── Badge de não lidas ───────────────────────────────────────────────────────

function updateUnreadBadge() {
  const total = conversations.reduce((acc, c) => acc + (c.unread_count || 0), 0);
  const badge = document.getElementById('nav-unread-badge');
  if (total > 0) {
    badge.textContent = total;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

// ─── WebSocket para mensagens em tempo real ───────────────────────────────────

function setupWebSocket() {
  ws = new WebSocket('ws://localhost:3000/ws');

  ws.onopen = () => {
    console.log('[WS] Conectado ao sistema de ramais.');
    // Polling leve a cada 5s para garantir sincronização
    pollInterval = setInterval(async () => {
      await loadConversations();
      if (activePartnerId) await loadMessages(activePartnerId);
    }, 5000);
  };

  ws.onmessage = async (e) => {
    try {
      const msg = JSON.parse(e.data);
      if (msg.type === 'new_extension_message') {
        const data = msg.data;
        // Se é a conversa ativa, adiciona a mensagem
        if (data.from_user_id === activePartnerId || data.to_user_id === activePartnerId) {
          if (data.from_user_id !== currentUser.id) {
            messages.push(data);
            renderMessages();
          }
        }
        await loadConversations();
        renderContactList();
      }
    } catch { /* ignora */ }
  };

  ws.onclose = () => {
    if (pollInterval) clearInterval(pollInterval);
    // Reconecta em 3s
    setTimeout(setupWebSocket, 3000);
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function escHtml(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function formatRelativeTime(isoStr) {
  const diff = Date.now() - new Date(isoStr).getTime();
  const min  = Math.floor(diff / 60000);
  if (min < 1)   return 'agora';
  if (min < 60)  return `${min}m`;
  const hrs = Math.floor(min / 60);
  if (hrs < 24)  return `${hrs}h`;
  return `${Math.floor(hrs / 24)}d`;
}
