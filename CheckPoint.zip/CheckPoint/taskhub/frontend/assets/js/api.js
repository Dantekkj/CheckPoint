// Wrapper centralizado para todas as chamadas à API do TaskHub.
// Injeta automaticamente o token JWT e trata erros de autenticação.

const API_BASE = 'http://localhost:3000/api';

async function api(path, opts = {}) {
  const token = localStorage.getItem('taskhub_token');

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(opts.headers || {}),
  };

  const res = await fetch(`${API_BASE}${path}`, { ...opts, headers });

  // Token expirado ou inválido — redireciona para login
  if (res.status === 401) {
    localStorage.clear();
    window.location.href = 'login.html';
    return;
  }

  const data = await res.json();

  if (!res.ok) {
    // Lança um erro com a mensagem da API para que o chamador possa tratar
    throw new Error(data.error || `Erro ${res.status}`);
  }

  return data;
}

// Atalhos para os métodos HTTP mais comuns

const API = {
  get:    (path)         => api(path, { method: 'GET' }),
  post:   (path, body)   => api(path, { method: 'POST',  body: JSON.stringify(body) }),
  patch:  (path, body)   => api(path, { method: 'PATCH', body: JSON.stringify(body) }),
  delete: (path)         => api(path, { method: 'DELETE' }),
};

// Expõe globalmente para todos os scripts da página
window.API = API;
