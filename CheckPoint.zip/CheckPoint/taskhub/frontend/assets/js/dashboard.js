// Dashboard do CheckPoint — KPIs de check-in + gráfico de pizza + feed de atividade.
// Conecta ao WebSocket para atualizações em tempo real.

(function () {
  if (!Auth.guard()) return;
  Auth.renderHeader();

  const user = Auth.getUser();

  // ─── WebSocket ───────────────────────────────────────────────────────────
  const WS_URL = 'ws://localhost:3000/ws';
  let ws;
  let reconnectTimer;

  function connectWS() {
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      setWsStatus(true);
      clearTimeout(reconnectTimer);
    };

    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === 'dashboard_snapshot' || msg.type === 'dashboard_tick') {
          updateKPIs(msg.data.stats);
          renderActivity(msg.data.activity);
        }
        if (msg.type === 'checkin_executor' || msg.type === 'checkin_validator') {
          // Recarrega pendências do usuário em tempo real
          loadMyPending();
          // Pisca o card de "Aguardando Validação"
          const el = document.getElementById('kpi-exec-done');
          if (el) { el.classList.add('text-amber-300'); setTimeout(() => el.classList.remove('text-amber-300'), 800); }
        }
      } catch { /* ignora */ }
    };

    ws.onerror = () => setWsStatus(false);
    ws.onclose = () => {
      setWsStatus(false);
      reconnectTimer = setTimeout(connectWS, 5000);
    };

    // Keep-alive
    setInterval(() => { if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'ping' })); }, 30000);
  }

  function setWsStatus(online) {
    const dot    = document.getElementById('ws-dot');
    const status = document.getElementById('ws-status');
    if (!dot || !status) return;
    if (online) {
      dot.className = 'live-dot w-2 h-2 rounded-full bg-green-500';
      status.textContent = 'Ao vivo';
    } else {
      dot.className = 'w-2 h-2 rounded-full bg-red-500';
      status.textContent = 'Desconectado';
    }
  }

  // ─── Gráfico de pizza ────────────────────────────────────────────────────
  let statusChart = null;

  function initChart() {
    const ctx = document.getElementById('chart-status');
    if (!ctx) return;
    statusChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Pendentes', 'Aguard. Validação', 'Aprovadas', 'Devolvidas'],
        datasets: [{
          data: [0, 0, 0, 0],
          backgroundColor: ['#334155', '#3730a3', '#065f46', '#7f1d1d'],
          borderColor:     ['#475569', '#818cf8', '#34d399', '#f87171'],
          borderWidth: 1.5,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#94a3b8', font: { size: 11 }, padding: 16 }
          }
        },
        cutout: '62%',
      }
    });
  }

  function updateChart(stats) {
    if (!statusChart) return;
    statusChart.data.datasets[0].data = [
      stats.pending      || 0,
      stats.executor_done || 0,
      stats.approved     || 0,
      stats.returned     || 0,
    ];
    statusChart.update();
  }

  // ─── KPIs ────────────────────────────────────────────────────────────────
  function updateKPIs(stats) {
    if (!stats) return;

    const total    = (stats.approved || 0) + (stats.returned || 0);
    const rate     = total > 0 ? Math.round((stats.approved / total) * 100) : '—';
    const open     = (stats.pending || 0) + (stats.executor_done || 0);

    setText('kpi-exec-done', stats.executor_done ?? 0);
    setText('kpi-approved',  stats.approved      ?? 0);
    setText('kpi-rate',      rate !== '—' ? rate + '%' : '—');
    setText('kpi-open',      open);
    setText('kpi-overdue',   (stats.overdue || 0) + ' atrasadas');

    const bar = document.getElementById('kpi-approved-bar');
    if (bar && stats.total > 0) {
      bar.style.width = Math.round((stats.approved / stats.total) * 100) + '%';
    }

    updateChart(stats);
  }

  // ─── Feed de atividade ───────────────────────────────────────────────────
  const typeLabels = {
    checkin_exec:       { icon: '📤', label: 'fez o check-in de conclusão',   color: 'text-indigo-400' },
    checkin_val_ok:     { icon: '✅', label: 'aprovou',                        color: 'text-green-400'  },
    checkin_val_return: { icon: '↩️', label: 'devolveu para correção',         color: 'text-red-400'    },
  };

  function renderActivity(items) {
    const list = document.getElementById('activity-list');
    if (!list) return;
    if (!items || items.length === 0) {
      list.innerHTML = '<li class="text-sm text-slate-500">Nenhum check-in recente.</li>';
      return;
    }
    list.innerHTML = items.map(item => {
      const meta = typeLabels[item.type] || { icon: '🔔', label: 'atualizou', color: 'text-slate-400' };
      const time = formatRelative(item.created_at);
      return `
        <li class="flex items-start gap-3">
          <div class="w-8 h-8 bg-slate-800 rounded-full flex items-center justify-center text-sm flex-shrink-0 border border-slate-700 font-bold text-indigo-400">
            ${item.author_avatar || item.author_name?.[0] || '?'}
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-sm text-slate-300">
              <span class="font-medium text-white">${esc(item.author_name)}</span>
              <span class="${meta.color}"> ${meta.icon} ${meta.label}</span>
            </p>
            <p class="text-xs text-slate-500 truncate">${esc(item.task_title)}</p>
            ${item.content ? `<p class="text-xs text-slate-600 mt-0.5 line-clamp-1 italic">"${esc(item.content)}"</p>` : ''}
          </div>
          <span class="text-xs text-slate-600 flex-shrink-0 mt-0.5">${time}</span>
        </li>`;
    }).join('');
  }

  // ─── Minhas pendências ───────────────────────────────────────────────────
  async function loadMyPending() {
    try {
      const tasks = await API.get('/tasks?mine=true');
      const active = tasks.filter(t => t.status !== 'approved');
      const list = document.getElementById('my-pending-list');
      if (!list) return;

      if (active.length === 0) {
        list.innerHTML = '<li class="text-sm text-slate-500">Nenhuma pendência 🎉</li>';
        return;
      }

      list.innerHTML = active.slice(0, 5).map(t => {
        const isExecutor  = t.assignee_id  === user.id;
        const isValidator = t.validator_id === user.id;

        let action = '';
        if (t.status === 'pending' && isExecutor) {
          action = `<span class="text-xs text-indigo-400 font-medium">Seu turn → executar</span>`;
        } else if (t.status === 'executor_done' && isValidator) {
          action = `<span class="text-xs text-amber-400 font-medium">Seu turno → validar</span>`;
        } else if (t.status === 'returned' && isExecutor) {
          action = `<span class="text-xs text-red-400 font-medium">Devolvida → corrigir</span>`;
        } else {
          action = `<span class="text-xs text-slate-500">${statusLabel(t.status)}</span>`;
        }

        return `
          <li class="flex items-center justify-between gap-2">
            <a href="tasks.html" class="text-xs text-slate-300 hover:text-white truncate transition" title="${esc(t.title)}">
              ${esc(t.title)}
            </a>
            ${action}
          </li>`;
      }).join('');
    } catch { /* silencioso */ }
  }

  // ─── Utilitários ─────────────────────────────────────────────────────────
  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  function esc(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function formatRelative(iso) {
    if (!iso) return '';
    const diff = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (diff < 1)   return 'agora';
    if (diff < 60)  return diff + 'min';
    if (diff < 1440) return Math.round(diff / 60) + 'h';
    return Math.round(diff / 1440) + 'd';
  }

  function statusLabel(s) {
    return { pending:'Pendente', executor_done:'Aguard. val.', approved:'Aprovada', returned:'Devolvida' }[s] || s;
  }

  // ─── Init ────────────────────────────────────────────────────────────────
  async function init() {
    initChart();
    connectWS();
    loadMyPending();

    // Carrega stats iniciais via REST (fallback caso WS demore)
    try {
      const stats = await API.get('/tasks/stats');
      updateKPIs(stats);
    } catch { /* WS cobrirá */ }
  }

  init();
})();
