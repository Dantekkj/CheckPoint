
// Helpers de autenticação: guardar token, ler usuário logado,
// proteger páginas e montar o cabeçalho de navegação.

const Auth = {
  // Salva o token e os dados do usuário após o login
  save(token, user) {
    localStorage.setItem('taskhub_token', token);
    localStorage.setItem('taskhub_user', JSON.stringify(user));
  },

  // Retorna o objeto do usuário logado (ou null se não estiver autenticado)
  getUser() {
    try {
      return JSON.parse(localStorage.getItem('taskhub_user'));
    } catch {
      return null;
    }
  },

  // Retorna o token JWT armazenado
  getToken() {
    return localStorage.getItem('taskhub_token');
  },

  // Verifica se o usuário está autenticado
  isLoggedIn() {
    return !!this.getToken() && !!this.getUser();
  },

  // Verifica se o usuário tem role de líder
  isLeader() {
    return this.getUser()?.role === 'leader';
  },

  // Limpa tudo e vai para o login
  logout() {
    localStorage.clear();
      window.location.href = 'login.html';
  },


// Deve ser chamado no topo de cada página protegida.
// Se o usuário não estiver logado, redireciona para o login.

  guard() {
    if (!this.isLoggedIn()) {
        window.location.href = 'login.html';
      return false;
    }
    return true;
  },


// Preenche o cabeçalho de navegação com o nome e avatar do usuário.
// Espera um elemento com id="user-name" e id="user-avatar" no HTML.

  renderHeader() {
    const user = this.getUser();
    if (!user) return;

    const nameEl   = document.getElementById('user-name');
    const avatarEl = document.getElementById('user-avatar');
    const roleEl   = document.getElementById('user-role');

    if (nameEl)   nameEl.textContent   = user.name;
    if (avatarEl) avatarEl.textContent = user.avatar || user.name[0];
    if (roleEl)   roleEl.textContent   = user.role === 'leader' ? 'Tech Lead' : user.position || 'Membro';

    // Esconde elementos que só o líder pode ver
    if (!this.isLeader()) {
      document.querySelectorAll('[data-leader-only]').forEach((el) => {
        el.style.display = 'none';
      });
    }

    // Botão de logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => this.logout());
    }
  },
};

window.Auth = Auth;
