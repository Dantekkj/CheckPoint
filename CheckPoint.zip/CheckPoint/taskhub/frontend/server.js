// Servidor HTTP simples para servir os arquivos do frontend
// Execute: node server.js (na pasta frontend)

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8080;
const MIME_TYPES = {
  '.html': 'text/html',
  '.js': 'application/javascript',
  '.css': 'text/css',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.json': 'application/json'
};

const server = http.createServer((req, res) => {
  // Remove query string e decodifica URL
  let filePath = path.join(__dirname, decodeURIComponent(req.url));
  
  // Se é raiz, serve login.html
  if (filePath.endsWith('/')) {
    filePath = path.join(filePath, 'login.html');
  }

  // Previne directory traversal
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  // Lê e serve o arquivo
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 Not Found');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, { 
      'Content-Type': contentType,
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'no-cache'
    });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log('');
  console.log('  Frontend rodando em → http://localhost:' + PORT);
  console.log('  Login                 → http://localhost:' + PORT + '/login.html');
  console.log('  Dashboard             → http://localhost:' + PORT + '/dashboard.html');
  console.log('');
  console.log('  Certifique-se de que o backend está rodando em http://localhost:3000/api');
  console.log('');
});
